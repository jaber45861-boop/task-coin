"""Automatic USDT/EGP quote fetcher.

This module only fetches and validates a market quote. It does not write
financial state; callers must persist the quote through the rate store.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from decimal import Decimal
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import json

from rate_quote import RateQuote, RateValidationError, parse_rate

PROVIDER_COINGECKO = "coingecko"
DEFAULT_ENDPOINT = "https://api.coingecko.com/api/v3/simple/price"
DEFAULT_TIMEOUT_SECONDS = 8


class RateProviderError(RuntimeError):
    """The external quote could not be trusted or retrieved."""


def fetch_usdt_egp_quote(*, now: datetime | None = None,
                         timeout: float = DEFAULT_TIMEOUT_SECONDS) -> RateQuote:
    """Fetch the current tether/EGP market quote from CoinGecko.

    The endpoint, optional API key and timeout are configurable by env.
    Invalid, missing, non-positive, malformed or non-JSON responses fail
    closed. Timestamp is the local UTC fetch time, not a provider timestamp.
    """
    endpoint = os.environ.get("TASKCOIN_RATE_API_URL", DEFAULT_ENDPOINT)
    api_key = os.environ.get("COINGECKO_API_KEY", "").strip()
    params = urlencode({"ids": "tether", "vs_currencies": "egp"})
    url = f"{endpoint}?{params}"
    headers = {"Accept": "application/json", "User-Agent": "task-coin-rate/1.0"}
    if api_key:
        headers["x-cg-demo-api-key"] = api_key
    request = Request(url, headers=headers, method="GET")
    try:
        with urlopen(request, timeout=timeout) as response:
            if response.status != 200:
                raise RateProviderError(f"rate provider returned HTTP {response.status}")
            payload = json.loads(response.read(65536).decode("utf-8"))
    except RateProviderError:
        raise
    except Exception as exc:
        raise RateProviderError("rate provider request failed") from exc

    try:
        value = payload["tether"]["egp"]
        rate = parse_rate(str(value))
    except (KeyError, TypeError, ValueError, RateValidationError) as exc:
        raise RateProviderError("rate provider response has no valid tether/egp quote") from exc

    captured_at = now or datetime.now(timezone.utc)
    if captured_at.tzinfo is None or captured_at.utcoffset() is None:
        raise RateProviderError("quote timestamp must be timezone-aware")
    return RateQuote(rate, PROVIDER_COINGECKO, captured_at)
