"""Background refresh loop for the authoritative USDT/EGP market quote."""
from __future__ import annotations

import logging
import threading

import rate_api
import rate_store

logger = logging.getLogger(__name__)
REFRESH_INTERVAL_SECONDS = 840  # refresh before the 900-second freshness boundary
_worker_lock = threading.Lock()
_worker_thread: threading.Thread | None = None
_stop_event = threading.Event()


def _run() -> None:
    while not _stop_event.is_set():
        try:
            quote = rate_api.fetch_usdt_egp_quote()
            rate_store.set_automatic_rate(quote)
            logger.info(
                "Automatic USDT/EGP quote refreshed: provider=%s captured_at=%s",
                quote.provider, quote.captured_at.isoformat(),
            )
        except Exception:
            # Keep the previous quote for audit only. get_current_quote
            # rejects it once stale; never refresh its timestamp on failure.
            logger.exception("Automatic USDT/EGP quote refresh failed")
        if _stop_event.wait(REFRESH_INTERVAL_SECONDS):
            break


def start() -> None:
    """Start one daemon worker; safe to call more than once."""
    global _worker_thread
    with _worker_lock:
        if _worker_thread is not None and _worker_thread.is_alive():
            return
        _stop_event.clear()
        _worker_thread = threading.Thread(
            target=_run, name="taskcoin-rate-refresh", daemon=True
        )
        _worker_thread.start()


def stop(timeout: float = 2.0) -> None:
    """Ask the worker to stop, primarily for controlled shutdown/tests."""
    _stop_event.set()
    thread = _worker_thread
    if thread is not None and thread.is_alive():
        thread.join(timeout=timeout)
