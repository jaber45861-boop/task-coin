# Task-Coin: Automatic USDT/EGP Rate — Development Snapshot

This archive is a development-only snapshot. It has NOT been deployed to production.

## Intended behavior
- Fetch USDT/EGP from CoinGecko automatically.
- Refresh the stored quote on a background worker (configured to refresh before the 900-second freshness boundary).
- Reject missing or stale quotes when creating EGP deposit requests.
- Freeze the rate, provider, capture time, and calculated USDT units on each request.
- Credit the frozen amount on approval; never recalculate with a later market quote.
- Include conversion details in ledger metadata and preserve atomic credit/idempotency behavior.

## Verification performed
- Python compilation checks passed for rate_api.py, rate_worker.py, rate_store.py, rate_quote.py, deposit_store.py, deposit_verification.py, db.py, bot.py, and test_rate_api.py.
- Full relevant pytest run is BLOCKED during collection because `python-telegram-bot` (`telegram`) is missing from this execution environment. No claim is made that the full test suite passes.
- The production server and production database were not accessed or changed.

## Before release
1. Install dependencies from the project's pinned dependency file in an isolated development environment.
2. Run rate, deposit-store, verification, and proof-review test suites; fix any regressions.
3. Test a full EGP deposit lifecycle against a disposable SQLite database.
4. Review the chosen market source's pricing/terms and configure `COINGECKO_API_KEY` if required.
5. Obtain explicit approval before any production migration or deployment.
