# Automatic EGP → USDT rate implementation (development copy)

## Behavior added
- `rate_api.py` fetches the `tether` / `egp` quote from CoinGecko's simple-price endpoint.
- `rate_worker.py` starts a daemon refresh loop from `bot.main()` and refreshes every 840 seconds so the 900-second quote TTL is not routinely crossed by scheduler delay.
- `rate_store.set_automatic_rate()` stores provider `coingecko`, exact decimal text, and the server-side capture timestamp. It never refreshes the timestamp after a failed fetch.
- `deposit_requests` gains additive nullable snapshot fields: `wallet_rate_usdt_egp`, `rate_provider`, `rate_captured_at`, `credited_usdt_units`.
- EGP request creation reads a fresh quote on the same SQLite transaction and stores the exact converted USDT atomic units.
- The credit boundary keeps the USDT path unchanged and uses the frozen snapshot for EGP, writing rate and conversion metadata to the ledger.

## Configuration
- Optional `COINGECKO_API_KEY` is sent as `x-cg-demo-api-key`.
- Optional `TASKCOIN_RATE_API_URL` overrides the API endpoint for controlled testing.
- No API key is included in this source tree.

## Important validation status
- Python syntax compilation passed for the edited Python modules.
- The pytest collection could not complete in this environment because `python-telegram-bot` (`telegram`) is not installed. Therefore behavioral tests, integration tests, and the complete suite are **not verified**.
- Before production release, install the repository's pinned requirements and run the targeted rate/deposit tests plus the full suite.
- The first rate fetch runs asynchronously in a daemon thread at bot startup. Until a valid quote is fetched, new EGP deposit requests fail closed. A failed refresh leaves the prior capture timestamp intact, and the existing 900-second TTL rejects it when stale.
- This archive is a development patch only. It has not been deployed and must not be copied to production until tests pass and the patch is reviewed.
