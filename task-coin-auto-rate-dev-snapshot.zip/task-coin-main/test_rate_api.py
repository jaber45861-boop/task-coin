from datetime import datetime, timezone
from io import BytesIO
from unittest.mock import patch
import json
import pytest

import rate_api


class FakeResponse:
    status = 200
    def __init__(self, payload):
        self.payload = payload
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def read(self, limit):
        return json.dumps(self.payload).encode()


def test_fetches_and_validates_quote():
    now = datetime(2026, 10, 12, tzinfo=timezone.utc)
    with patch.object(rate_api, "urlopen", return_value=FakeResponse(
        {"tether": {"egp": 50.25}}
    )):
        quote = rate_api.fetch_usdt_egp_quote(now=now)
    assert str(quote.rate_usdt_egp) == "50.25"
    assert quote.provider == "coingecko"
    assert quote.captured_at == now


@pytest.mark.parametrize("payload", [
    {}, {"tether": {}}, {"tether": {"egp": 0}},
    {"tether": {"egp": -1}}, {"tether": {"egp": "bad"}},
])
def test_rejects_invalid_provider_payload(payload):
    with patch.object(rate_api, "urlopen", return_value=FakeResponse(payload)):
        with pytest.raises(rate_api.RateProviderError):
            rate_api.fetch_usdt_egp_quote()


def test_rejects_network_failure():
    with patch.object(rate_api, "urlopen", side_effect=TimeoutError("timeout")):
        with pytest.raises(rate_api.RateProviderError):
            rate_api.fetch_usdt_egp_quote()
