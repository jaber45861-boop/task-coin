import os
import random
import re
import logging
import json
from dotenv import load_dotenv
from telegram import (
    BotCommandScopeChat,
    BotCommandScopeDefault,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    MenuButtonWebApp,
    Update,
    WebAppInfo,
)
from telegram.error import TelegramError
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    ChatMemberHandler,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    ConversationHandler,
    filters,
)
from config import ADMINS, CHANNELS, Channel, is_admin, get_required_channels, get_mini_app_url
from subscription import (
    check_subscription_access,
    is_locked,
    lock_user,
    unlock_user,
)
import asyncio
import signal
import threading

from flask import Flask, send_from_directory
from waitress import create_server

import db
import admin_control
import admin_review_queue
import admin_task_wizard
import manual_proof_inbox
import deposit_proof_admin
import payment_method_admin
import rate_admin
import support_service
import task_creation
import task_request_admin
import task_request_notifications
import task_taxonomy
import withdrawal_admin
import withdrawal_notifications
import withdrawal_user
from admin_notifier import AdminNotifier
from telegram_channel_task_verifier import (
    TELEGRAM_CHANNEL_TASK_TYPE,
    TelegramChannelTaskDataError,
    validate_telegram_channel_task_data,
)

load_dotenv('/root/task-coin/.env')

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

ANTI_BOT = 0
ANTI_BOT_BLOCKED = 1

MAX_ANTI_BOT_ATTEMPTS = 3

# States for the interactive /addchannel conversation
ADDCHANNEL_USERNAME = 20
ADDCHANNEL_TITLE = 21

# States for the interactive /removechannel conversation
REMOVECHANNEL_SELECT = 30
REMOVECHANNEL_CONFIRM = 31

# ── Language selection (first step of /start) ────────────────────────
# Asked once, before the Anti-Bot step, when no language is persisted.
# Values are constrained to db.SUPPORTED_LANGUAGES: ar, en, ru, fa.
LANGUAGE_SELECT = 2
LANGUAGE_PROMPT = (
    "🌐 اختر اللغة\n"
    "Choose your language\n"
    "Выберите язык\n"
    "زبان خود را انتخاب کنید"
)
LANGUAGE_BUTTONS: tuple[tuple[str, str], ...] = (
    ("ar", "🇪🇬 العربية"),
    ("en", "🇬🇧 English"),
    ("ru", "🇷🇺 Русский"),
    ("fa", "🇮🇷 فارسی"),
)
LANGUAGE_CALLBACK_ANY = r"^lang:"


def _language_code(data: object) -> str | None:
    """Extract a supported code from ``lang:<code>`` callback data.

    Returns None for anything that is not exactly one of ar/en/ru/fa, so
    invalid or malformed callback data is rejected safely.
    """
    if not isinstance(data, str) or not data.startswith("lang:"):
        return None
    code = data[len("lang:"):]
    return code if db.is_supported_language(code) else None


def _language_keyboard() -> InlineKeyboardMarkup:
    """Inline keyboard with the four supported languages."""
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(label, callback_data=f"lang:{code}")]
            for code, label in LANGUAGE_BUTTONS
        ]
    )


async def _send_math_question(message) -> tuple[str, int]:
    """Generate a math question and return (question_text, answer)."""
    a = random.randint(1, 20)
    b = random.randint(1, 20)
    op = random.choice(["+", "-"])

    if op == "-" and a < b:
        a, b = b, a

    correct = a + b if op == "+" else a - b
    return f"🔒 للتحقق أنك لست بوت:\n\nما ناتج: {a} {op} {b}؟", correct


def _non_private_chat(update: Update) -> bool:
    """Return True only when *update* positively targets a group/channel.

    MT-ADMIN-02 isolation guard: the private chat is the operational
    control plane, so user-facing handlers (onboarding, anti-bot,
    subscription gating) must never run — or reply — outside private
    chats.  Updates whose chat type cannot be resolved (no chat, or a
    test double without a real chat type) are NOT treated as groups, so
    existing direct-handler behaviour is unchanged.
    """
    chat = getattr(update, "effective_chat", None)
    chat_type = getattr(chat, "type", None)
    return isinstance(chat_type, str) and chat_type != "private"


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Start the /start flow: language gate first, then Anti-Bot.

    Also captures referral payload from deep link if present.
    """
    # MT-ADMIN-02: /start must never start the private onboarding flow
    # inside groups or channels — stay silent and start nothing.
    if _non_private_chat(update):
        return ConversationHandler.END

    # ── Referral attribution (capture before anti-bot flow) ──────────
    user = update.effective_user
    user_id = user.id
    username = user.username
    first_name = user.first_name

    # Extract referral payload if present
    referred_by = None
    if context.args and len(context.args) > 0:
        try:
            referred_by = int(context.args[0])
        except (ValueError, TypeError):
            referred_by = None

    # Register user with referral attribution (idempotent)
    db.register_user(
        user_id=user_id,
        username=username,
        first_name=first_name,
        referred_by=referred_by,
    )

    # ── Language gate: asked once, before the Anti-Bot step ────────────
    # First-time users pick a language and the normal flow stops here;
    # users with a persisted language continue untouched.
    if db.get_user_language(user_id) is None:
        await update.message.reply_text(
            LANGUAGE_PROMPT, reply_markup=_language_keyboard()
        )
        return LANGUAGE_SELECT

    # ── Existing flow (anti-bot challenge) ─────────────────────────
    return await _begin_anti_bot(update.message, context)


async def _begin_anti_bot(message, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Shared /start continuation: send the Anti-Bot challenge.

    Used both by ``start`` (language already persisted) and by the
    language callback after the choice is saved, so the /start flow is
    never duplicated.  Anti-Bot rules are unchanged.
    """
    question, correct = await _send_math_question(message)
    context.user_data["anti_bot_answer"] = correct
    context.user_data["anti_bot_attempts"] = 0

    await message.reply_text(question)
    return ANTI_BOT


async def language_selected(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Handle a language button press while selection is pending.

    Persists the choice for the pressing user only, then resumes the
    existing /start flow from the Anti-Bot step.  Safe on repeated
    presses and on invalid/stale callback data.
    """
    if _non_private_chat(update):
        return ConversationHandler.END
    query = update.callback_query
    code = _language_code(query.data)
    if code is None:
        await query.answer("⚠️ لغة غير صالحة", show_alert=False)
        return LANGUAGE_SELECT

    await query.answer()
    if query.message is None:
        # Nothing to reply the challenge to — keep selection pending.
        return LANGUAGE_SELECT
    if not db.set_user_language(query.from_user.id, code):
        # Unknown user row (stale state) — fail safely, stay here.
        return LANGUAGE_SELECT

    # Drop the keyboard so the choice cannot be re-pressed casually.
    try:
        await query.edit_message_reply_markup(reply_markup=None)
    except TelegramError:
        pass  # stale/already-edited message — persisted state is correct

    # Resume the existing /start flow from the correct point.
    return await _begin_anti_bot(query.message, context)


async def language_prompt_again(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Stray text while selection is pending → re-show the prompt."""
    if _non_private_chat(update):
        return ConversationHandler.END
    await update.message.reply_text(
        LANGUAGE_PROMPT, reply_markup=_language_keyboard()
    )
    return LANGUAGE_SELECT


async def language_callback_fallback(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Safely answer stale or out-of-date language callbacks.

    Fires only when the conversation is *not* awaiting a language choice
    (same handler group, right after the conversation, so exactly one of
    them handles each update).  Never changes persisted state: an
    already-persisted language is left untouched (idempotent) and
    invalid codes are refused without touching anything.
    """
    if _non_private_chat(update):
        return
    query = update.callback_query
    code = _language_code(query.data)
    if code is None:
        await query.answer("⚠️ لغة غير صالحة", show_alert=False)
        return
    if db.get_user_language(query.from_user.id):
        await query.answer("✅")  # already chosen — idempotent no-op
        return
    # Valid button but no /start selection in progress (stale/restarted).
    await query.answer(
        "يرجى إرسال /start للبدء من جديد", show_alert=False
    )


async def _blocked(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle messages from users who exhausted their anti-bot attempts."""
    if _non_private_chat(update):
        return ConversationHandler.END
    await update.message.reply_text(
        "🚫 لقد تجاوزت الحد الأقصى للمحاولات. "
        "أرسل /start للبدء من جديد."
    )
    return ANTI_BOT_BLOCKED


async def check_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Check the user's answer with up to 3 attempts."""
    if _non_private_chat(update):
        return ConversationHandler.END
    expected = context.user_data.get("anti_bot_answer")
    attempts = context.user_data.get("anti_bot_attempts", 0)
    text = update.message.text.strip()

    try:
        user_answer = int(text)
    except ValueError:
        attempts += 1
        context.user_data["anti_bot_attempts"] = attempts
        if attempts >= MAX_ANTI_BOT_ATTEMPTS:
            context.user_data.pop("anti_bot_answer", None)
            context.user_data.pop("anti_bot_attempts", None)
            await update.message.reply_text(
                "🚫 لقد تجاوزت الحد الأقصى للمحاولات. "
                "أرسل /start للبدء من جديد."
            )
            return ANTI_BOT_BLOCKED
        question, new_correct = await _send_math_question(update.message)
        context.user_data["anti_bot_answer"] = new_correct
        remaining = MAX_ANTI_BOT_ATTEMPTS - attempts
        await update.message.reply_text(
            "❌ إجابة غير صحيحة. "
            f"متبقي {remaining} محاولة."
        )
        await update.message.reply_text(question)
        return ANTI_BOT

    if user_answer != expected:
        attempts += 1
        context.user_data["anti_bot_attempts"] = attempts
        if attempts >= MAX_ANTI_BOT_ATTEMPTS:
            context.user_data.pop("anti_bot_answer", None)
            context.user_data.pop("anti_bot_attempts", None)
            await update.message.reply_text(
                "🚫 لقد تجاوزت الحد الأقصى للمحاولات. "
                "أرسل /start للبدء من جديد."
            )
            return ANTI_BOT_BLOCKED
        question, new_correct = await _send_math_question(update.message)
        context.user_data["anti_bot_answer"] = new_correct
        remaining = MAX_ANTI_BOT_ATTEMPTS - attempts
        await update.message.reply_text(
            "❌ إجابة غير صحيحة. "
            f"متبقي {remaining} محاولة."
        )
        await update.message.reply_text(question)
        return ANTI_BOT

    # ── Anti-bot passed — check channel subscriptions ───────────────
    context.user_data.pop("anti_bot_attempts", None)
    required = get_required_channels()
    if not required:
        await update.message.reply_text("✅ تحقق ناجح! أنت لست بوت.")
        context.user_data.pop("anti_bot_answer", None)
        return ConversationHandler.END

    user_id = update.effective_user.id
    subscribed, missing = await check_subscription_access(
        context.bot, user_id
    )

    context.user_data.pop("anti_bot_answer", None)

    if subscribed:
        unlock_user(user_id)
        await update.message.reply_text(
            "✅ تحقق ناجح! أنت لست بوت.\n"
            "✅ أنت مشترك في جميع القنوات المطلوبة."
        )
    else:
        lock_user(user_id)
        text, markup = _build_missing_message(missing)
        await update.message.reply_text(text, reply_markup=markup)

    return ConversationHandler.END


# ── Subscription helpers ────────────────────────────────────────────

def _build_missing_message(
    missing: list[Channel],
) -> tuple[str, InlineKeyboardMarkup]:
    """Build the text + keyboard for missing-channel messages."""
    buttons: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(
            text=f"📢 {ch.title}",
            url=f"https://t.me/{ch.username}",
        )]
        for ch in missing
    ]
    buttons.append(
        [InlineKeyboardButton(
            text="✅ تحقق من الاشتراك",
            callback_data="verify_subscription",
        )]
    )
    names = "\n".join(f"  • {ch.title}" for ch in missing)
    text = (
        "✅ تحقق ناجح! أنت لست بوت.\n\n"
        "⚠️ أنت غير مشترك في القنوات التالية:\n"
        f"{names}\n\n"
        "اضغط الزر للاشتراك ثم اضغط \"تحقق من الاشتراك\":"
    )
    return text, InlineKeyboardMarkup(buttons)


async def verify_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Re-check all required channels when the verify button is pressed."""
    if _non_private_chat(update):
        # MT-ADMIN-02: never answer/edit anything inside groups/channels.
        return
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    required = get_required_channels()

    if not required:
        await query.edit_message_text(
            "✅ لا توجد قنوات مطلوبة حالياً."
        )
        return

    missing: list[Channel] = []
    for ch in required:
        try:
            member = await context.bot.get_chat_member(ch.channel_id, user_id)
            if member.status not in (
                "member",
                "administrator",
                "creator",
            ):
                missing.append(ch)
        except TelegramError:
            missing.append(ch)

    if not missing:
        unlock_user(user_id)
        await query.edit_message_text(
            "✅ تحقق ناجح! أنت مشترك في جميع القنوات المطلوبة."
        )
    else:
        lock_user(user_id)
        text, markup = _build_missing_message(missing)
        await query.edit_message_text(text, reply_markup=markup)


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Cancel the anti-bot check."""
    if _non_private_chat(update):
        return ConversationHandler.END
    context.user_data.pop("anti_bot_answer", None)
    await update.message.reply_text("تم الإلغاء.")
    return ConversationHandler.END


# ── Channel-reference normalizer ────────────────────────────────────

# Matches @username, t.me/username, and bare username strings.
# Accepts https://, http://, bare t.me/, www.t.me/ prefixes.
_USERNAME_RE = re.compile(
    r"^(?:(?:https?://)?(?:www\.)?t\.me/)?@?([A-Za-z0-9_]{5,})$",
)


def _normalize_channel_ref(raw: str) -> str | None:
    """Extract a clean Telegram username from various input formats.

    Accepted inputs:
        @channelusername
        https://t.me/channelusername
        http://t.me/channelusername
        www.t.me/channelusername
        t.me/channelusername
        channelusername

    Returns the bare username (without @) on success, or None.
    """
    m = _USERNAME_RE.match(raw.strip())
    if m:
        return m.group(1)
    return None


# ── Admin: Add Channel ───────────────────────────────────────────────

async def add_channel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Add a mandatory subscription channel. Admin only.

    Usage: /addchannel slug|@username|title
           /addchannel slug|https://t.me/username|title
    The bot resolves the channel automatically via get_chat().
    """
    user_id = update.effective_user.id
    if not is_admin(user_id):
        subscribed, missing = await check_subscription_access(
            context.bot, user_id
        )
        if not subscribed:
            lock_user(user_id)
            text, markup = _build_missing_message(missing)
            await update.message.reply_text(text, reply_markup=markup)
            return
        unlock_user(user_id)
        await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return

    text = update.message.text.replace("/addchannel", "", 1).strip()
    parts = [p.strip() for p in text.split("|")]

    if len(parts) != 3:
        await update.message.reply_text(
            "❌ صيغة خاطئة. استخدم:\n"
            "/addchannel slug|@username|title\n\n"
            "أو:\n"
            "/addchannel slug|https://t.me/username|title\n\n"
            "مثال:\n"
            "/addchannel main|@mychannel|My Channel"
        )
        return

    slug, channel_ref, title = parts

    # Validate slug
    if not slug or not slug.isalnum() and "_" not in slug:
        await update.message.reply_text(
            "❌ الـslug يجب أن يحتوي على أحرف وأرقام فقط (والشرطة السفلية _)."
        )
        return

    # Normalize channel reference
    username = _normalize_channel_ref(channel_ref)
    if not username:
        await update.message.reply_text(
            "❌ صيغة غير صحيحة لاسم القناة.\n"
            "استخدم @username أو https://t.me/username"
        )
        return

    # Prevent duplicate slug
    if slug in CHANNELS:
        await update.message.reply_text(
            f"❌ الـslug '{slug}' موجود مسبقًا."
        )
        return

    # ── Resolve channel via Telegram Bot API ────────────────────────
    try:
        chat = await context.bot.get_chat(f"@{username}")
    except TelegramError as exc:
        await update.message.reply_text(
            "❌ تعذر الوصول للقناة. تأكد من:\n"
            "• اسم القناة صحيح\n"
            "• البوت مضاف للقناة\n\n"
            f"تفاصيل الخطأ: {exc}"
        )
        return

    # Verify it's a channel or supergroup
    if chat.type not in ("channel", "supergroup"):
        await update.message.reply_text(
            f'❌ "{chat.type}" ليست قناة أو supergroup.\n'
            "يجب أن يكون المعرف الخاص بقناة أو supergroup Telegram."
        )
        return

    channel_id = chat.id

    # Prevent duplicate channel_id
    for existing in CHANNELS.values():
        if existing.channel_id == channel_id:
            await update.message.reply_text(
                f"❌ القناة @{username} (ID: {channel_id}) موجودة مسبقًا "
                f"(slug: {existing.slug})."
            )
            return

    # Verify the bot has access in the channel/supergroup.
    # For channels the bot must be admin (Telegram API requirement).
    # For supergroups a regular member is enough.
    try:
        bot_member = await context.bot.get_chat_member(
            channel_id, context.bot.id
        )
    except TelegramError as exc:
        await update.message.reply_text(
            "❌ تعذر التحقق من عضوية البوت في القناة/المجموعة.\n"
            "تأكد أن البوت مضاف للقناة أو المجموعة\n"
            "ليتمكن من فحص اشتراك المستخدمين لاحقًا.\n\n"
            f"تفاصيل الخطأ: {exc}"
        )
        return

    if chat.type == "channel":
        _bot_ok = bot_member.status in ("administrator", "creator")
    else:
        _bot_ok = bot_member.status in (
            "member", "administrator", "creator",
        )

    if not _bot_ok:
        await update.message.reply_text(
            f"❌ البوت ليس عضوًا كافيًا في {chat.type} (حالته: {bot_member.status})\n"
            "يجب أن يكون البوت *مشرفًا* (admin) في القناة\n"
            "أو *عضوًا* (member) في المجموعة."
        )
        return

    # Add the channel
    new_channel = Channel(
        slug=slug,
        channel_id=channel_id,
        username=username,
        title=title,
        required=True,
        chat_type=chat.type,
    )
    CHANNELS[slug] = new_channel
    db.save_channel(new_channel)

    await update.message.reply_text(
        "✅ تمت إضافة القناة:\n\n"
        f"📌 Slug: {slug}\n"
        f"🆔 ID: {channel_id}\n"
        f"📛 Username: @{username}\n"
        f"📝 Title: {title}\n"
        f"🔒 Required: نعم"
    )
    logger.info("Channel added: %s (id=%d) by admin %d", slug, channel_id, user_id)


# NOTE: The legacy add_channel handler is retained for backward-compatible
# unit tests.  The interactive /addchannel ConversationHandler below
# replaces it in the running bot.


def _derive_slug(username: str) -> str:
    """Derive a safe channel slug from a Telegram username."""
    slug = re.sub(r"[^a-z0-9_]", "", username.lower())
    return slug or "channel"


async def addchannel_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Entry point for the interactive /addchannel workflow.

    Checks admin privileges, then prompts for the channel username/link.
    Works for both /addchannel command and admin panel callback.
    """
    user_id = update.effective_user.id
    if not is_admin(user_id):
        subscribed, missing = await check_subscription_access(
            context.bot, user_id
        )
        if not subscribed:
            lock_user(user_id)
            text, markup = _build_missing_message(missing)
            if update.callback_query:
                await update.callback_query.answer()
                await update.callback_query.edit_message_text(
                    text, reply_markup=markup
                )
            else:
                await update.message.reply_text(text, reply_markup=markup)
            return ConversationHandler.END
        unlock_user(user_id)
        if update.callback_query:
            await update.callback_query.answer()
            await update.callback_query.edit_message_text(
                "⛔ هذا الأمر للمشرفين فقط."
            )
        else:
            await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return ConversationHandler.END

    # Clean up any leftover state from a previous interrupted flow.
    context.user_data.pop("addchannel_channel_id", None)
    context.user_data.pop("addchannel_username", None)
    context.user_data.pop("addchannel_chat_type", None)

    prompt = (
        "أرسل Username القناة مثل @Crypto1583 أو رابط القناة مثل "
        "https://t.me/Crypto1583"
    )
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(prompt)
    else:
        await update.message.reply_text(prompt)
    return ADDCHANNEL_USERNAME


async def addchannel_username(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Validate the channel username/link and prompt for the title."""
    text = update.message.text.strip()
    username = _normalize_channel_ref(text)

    if not username:
        await update.message.reply_text(
            "❌ صيغة غير صحيحة. أرسل Username مثل @Crypto1583\n"
            "أو رابط مثل https://t.me/Crypto1583"
        )
        return ADDCHANNEL_USERNAME

    # ── Validate via Telegram Bot API (same as the original handler) ──
    try:
        chat = await context.bot.get_chat(f"@{username}")
    except TelegramError as exc:
        await update.message.reply_text(
            "❌ تعذر الوصول للقناة. تأكد من:\n"
            "• اسم القناة صحيح\n"
            "• البوت مضاف للقناة\n\n"
            f"تفاصيل الخطأ: {exc}"
        )
        return ADDCHANNEL_USERNAME

    # Verify it's a channel or supergroup
    if chat.type not in ("channel", "supergroup"):
        await update.message.reply_text(
            f'❌ "{chat.type}" ليست قناة أو supergroup.\n'
            "يجب أن يكون المعرف الخاص بقناة أو supergroup Telegram."
        )
        return ADDCHANNEL_USERNAME

    # Prevent duplicate channel_id
    for existing in CHANNELS.values():
        if existing.channel_id == chat.id:
            await update.message.reply_text(
                f"❌ القناة @{username} (ID: {chat.id}) موجودة مسبقًا "
                f"(slug: {existing.slug})."
            )
            return ADDCHANNEL_USERNAME

    # Verify the bot has access in the channel/supergroup.
    # For channels the bot must be admin (Telegram API requirement).
    # For supergroups a regular member is enough.
    try:
        bot_member = await context.bot.get_chat_member(
            chat.id, context.bot.id
        )
    except TelegramError as exc:
        await update.message.reply_text(
            "❌ تعذر التحقق من عضوية البوت في القناة/المجموعة.\n"
            "تأكد أن البوت مضاف للقناة أو المجموعة\n"
            "ليتمكن من فحص اشتراك المستخدمين لاحقًا.\n\n"
            f"تفاصيل الخطأ: {exc}"
        )
        return ADDCHANNEL_USERNAME

    if chat.type == "channel":
        _bot_ok = bot_member.status in ("administrator", "creator")
    else:
        _bot_ok = bot_member.status in (
            "member", "administrator", "creator",
        )

    if not _bot_ok:
        await update.message.reply_text(
            f"❌ البوت ليس عضوًا كافيًا في {chat.type} (حالته: {bot_member.status})\n"
            "يجب أن يكون البوت *مشرفًا* (admin) في القناة\n"
            "أو *عضوًا* (member) في المجموعة."
        )
        return ADDCHANNEL_USERNAME

    # Store validated data for the next step
    context.user_data["addchannel_channel_id"] = chat.id
    context.user_data["addchannel_username"] = username
    context.user_data["addchannel_chat_type"] = chat.type

    await update.message.reply_text("أرسل اسم القناة")
    return ADDCHANNEL_TITLE


async def addchannel_title(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Receive the title, persist the channel, and finish."""
    title = update.message.text.strip()
    if not title:
        await update.message.reply_text(
            "❌ اسم القناة لا يمكن أن يكون فارغًا.\nأرسل اسم القناة."
        )
        return ADDCHANNEL_TITLE

    channel_id = context.user_data.pop("addchannel_channel_id")
    username = context.user_data.pop("addchannel_username")
    chat_type = context.user_data.pop("addchannel_chat_type", "channel")

    slug = _derive_slug(username)
    # Ensure slug uniqueness
    if slug in CHANNELS:
        slug = f"{slug}_{abs(channel_id)}"

    new_channel = Channel(
        slug=slug,
        channel_id=channel_id,
        username=username,
        title=title,
        required=True,
        chat_type=chat_type,
    )
    CHANNELS[slug] = new_channel
    db.save_channel(new_channel)

    await update.message.reply_text(
        "✅ تمت إضافة القناة:\n\n"
        f"📌 Slug: {slug}\n"
        f"🆔 ID: {channel_id}\n"
        f"📛 Username: @{username}\n"
        f"📝 Title: {title}\n"
        "🔒 Required: نعم"
    )
    logger.info(
        "Channel added: %s (id=%d) via interactive flow", slug, channel_id
    )
    return ConversationHandler.END


async def addchannel_cancel(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Cancel the /addchannel conversation."""
    context.user_data.pop("addchannel_channel_id", None)
    context.user_data.pop("addchannel_username", None)
    context.user_data.pop("addchannel_chat_type", None)
    await update.message.reply_text("تم الإلغاء.")
    return ConversationHandler.END


# ── Admin: List Channels ─────────────────────────────────────────────

async def list_channels(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List all mandatory subscription channels. Admin only.

    MT-ADMIN-NEXT: private admin chat only — group/channel
    invocations stay silent before any authorization or read.
    """
    if _non_private_chat(update):
        return
    user_id = update.effective_user.id
    if not is_admin(user_id):
        subscribed, missing = await check_subscription_access(
            context.bot, user_id
        )
        if not subscribed:
            lock_user(user_id)
            text, markup = _build_missing_message(missing)
            await update.message.reply_text(text, reply_markup=markup)
            return
        unlock_user(user_id)
        await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return

    if not CHANNELS:
        await update.message.reply_text("📭 لا توجد قنوات اشتراك إجباري حالياً.")
        return

    lines = ["📋 *قنوات الاشتراك الإجباري:*\n"]
    for ch in CHANNELS.values():
        required_text = "نعم" if ch.required else "لا"
        lines.append(
            f"📌 *{ch.title}*\n"
            f"   slug: `{ch.slug}`\n"
            f"   ID: `{ch.channel_id}`\n"
            f"   username: @{ch.username}\n"
            f"   required: {required_text}\n"
        )

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
    logger.info("Channels listed by admin %d", user_id)


# ── Admin: Create Task ───────────────────────────────────────────────

ADD_TASK_USAGE = (
    "❌ صيغة خاطئة. استخدم:\n"
    "/addtask عنوان | وصف | المكافأة (USDT) | channel_slug\n\n"
    "مثال:\n"
    "/addtask انضم لقناتنا | اشترك في القناة | 0.0001 | main"
)


async def add_task(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Create a task from chat. Admin only.

    MT-ADMIN-05: a bare ``/addtask`` (no arguments) opens the
    canonical step-by-step wizard (``admin_task_wizard``) — private
    admin chat only.  The legacy pipe form below is retained for
    compatibility and delegates into the SAME ``task_creation``
    service the wizard publishes through (one validated creation
    path, never two).

    Usage: /addtask title | description | reward (USDT) | channel_slug

    Only the ``telegram_channel`` task type is supported here.  The
    channel_slug MUST already exist in the required-channel registry
    (config.CHANNELS).  The task is stored in the existing tasks table
    via db.create_task with exactly the MT-TASK-05 server-side
    task_data contract the registered verifier reads back:

        {
            "provider": "telegram",
            "action": "join_channel",
            "target": {"channel_slug": "<slug>"},
            "instructions": "<description>"
        }

    The payload is validated with the verifier's own
    ``validate_telegram_channel_task_data`` before persisting, so this
    writer can never store a task_data the reader rejects.

    Mandatory subscription channels are a separate concern: this
    handler only reads the registry to validate the slug and never
    adds, removes, or gates channels.

    MT-ADMIN-NEXT: private admin chat only — group/channel
    invocations stay silent before authorization or parsing, so the
    legacy pipe form never creates a task outside a private admin
    chat (the bare-form wizard already re-checks it itself).
    """
    if _non_private_chat(update):
        return
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return

    text = (update.message.text or "").strip()
    parts = text.split(maxsplit=1)
    args_text = parts[1] if len(parts) > 1 else ""

    if not args_text:
        # MT-ADMIN-05: bare /addtask → the canonical creation wizard.
        # start_wizard re-checks admin + private chat itself, so a
        # group invocation produces zero replies.
        await admin_task_wizard.start_wizard(update, context)
        return

    fields = [p.strip() for p in args_text.split("|")]

    if len(fields) != 4:
        await update.message.reply_text(ADD_TASK_USAGE)
        return

    title, description, points_text, slug = fields
    slug = slug.lstrip("@")

    if not title or not description or not slug:
        await update.message.reply_text(ADD_TASK_USAGE)
        return

    try:
        # MT-ADMIN-14: the ONE canonical exact reward parser — decimal
        # USDT text (≤ 8 dp) → atomic units; no float, no rounding.
        reward_units = task_creation.parse_reward_units(
            points_text, field="النقاط"
        )
    except ValueError as exc:
        await update.message.reply_text(str(exc))
        return

    if slug not in CHANNELS:
        await update.message.reply_text(
            f"❌ الـ channel_slug '{slug}' غير موجود في سجل القنوات.\n"
            "استخدم /listchannels لعرض السجل."
        )
        return

    # MT-ADMIN-05: the legacy pipe delegates into the SAME canonical
    # creation service the wizard publishes through — one validated
    # creation path, never two.  The service builds the exact
    # MT-TASK-05 contract and proves it with the verifier's own
    # validator before anything is persisted.
    #
    # Roadmap 4: the sending admin is the authenticated advertiser —
    # the service funds the task (reward + commission snapshot) from
    # that account atomically with the INSERT, never from payload
    # data.
    spec = task_creation.TaskSpec(
        title=title,
        description=description,
        provider="telegram",
        action="join_channel",
        target={"channel_slug": slug},
        verification=task_taxonomy.VERIFICATION_AUTO,
        reward=task_creation.whole_usdt_reward(reward_units),
        reward_units=reward_units,
    )
    try:
        task_id = task_creation.create_task_from_spec(
            spec, funding_advertiser_id=user_id
        )
    except TelegramChannelTaskDataError as exc:
        await update.message.reply_text(
            f"❌ بيانات المهمة غير صالحة: {exc}"
        )
        return
    except ValueError as exc:
        await update.message.reply_text(f"❌ تعذر إنشاء المهمة: {exc}")
        return

    await update.message.reply_text(
        "✅ تم إنشاء المهمة:\n\n"
        f"🆔 ID: {task_id}\n"
        f"📌 العنوان: {title}\n"
        f"📝 الوصف: {description}\n"
        f"💰 المكافأة: {task_creation.reward_units_to_text(reward_units)} USDT\n"
        f"📡 القناة: {slug}"
    )
    logger.info(
        "Task created: id=%d type=telegram_channel channel=%s by admin %d",
        task_id, slug, user_id,
    )


# ── Admin: List Tasks ───────────────────────────────────────────────

async def list_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List all task definitions (id, title, type, reward, active).

    Admin only.  Read-only: queries the existing tasks table via
    db.list_tasks() and never creates, modifies, or disables tasks.

    MT-ADMIN-NEXT: private admin chat only — group/channel
    invocations stay silent before any authorization or read, so
    task/reward listings never reach a group.
    """
    if _non_private_chat(update):
        return
    user_id = update.effective_user.id
    if not is_admin(user_id):
        subscribed, missing = await check_subscription_access(
            context.bot, user_id
        )
        if not subscribed:
            lock_user(user_id)
            text, markup = _build_missing_message(missing)
            await update.message.reply_text(text, reply_markup=markup)
            return
        unlock_user(user_id)
        await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return

    tasks = db.list_tasks()

    if not tasks:
        await update.message.reply_text("📭 لا توجد مهام حالياً.")
        return

    lines = ["📋 *قائمة المهام:*\n"]
    for task in tasks:
        active_text = "نعم" if task["active"] else "لا"
        lines.append(
            f"🆔 ID: `{task['id']}`\n"
            f"   📝 العنوان: *{task['title']}*\n"
            f"   📂 النوع: `{task['type']}`\n"
            f"   💰 المكافأة: `{task['reward']}`\n"
            f"   ✅ نشطة: {active_text}\n"
        )

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
    logger.info("Tasks listed by admin %d", user_id)


# ── Admin: Disable Task ─────────────────────────────────────────

async def off_task(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Disable a task (soft delete). Admin only.

    Usage: /offtask <id>

    Sets only ``active=False`` via ``db.update_task()``.  The task row
    is never removed: user_tasks history, task_submissions, approvals,
    and ledger rewards stay untouched, and the existing catalog,
    start-gate, and attempt-policy checks then exclude the task.

    MT-ADMIN-NEXT: private admin chat only — group/channel
    invocations stay silent before any authorization, read or
    write, so the mutation never runs from a group.
    """
    if _non_private_chat(update):
        return
    user_id = update.effective_user.id
    if not is_admin(user_id):
        subscribed, missing = await check_subscription_access(
            context.bot, user_id
        )
        if not subscribed:
            lock_user(user_id)
            text, markup = _build_missing_message(missing)
            await update.message.reply_text(text, reply_markup=markup)
            return
        unlock_user(user_id)
        await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return

    parts = (update.message.text or "").strip().split(maxsplit=1)
    id_text = parts[1].strip() if len(parts) > 1 else ""
    if not id_text.isdigit():
        await update.message.reply_text(
            "❌ صيغة خاطئة. استخدم:\n"
            "/offtask <id>\n\n"
            "مثال:\n"
            "/offtask 1"
        )
        return

    task_id = int(id_text)
    task = db.get_task(task_id)
    if task is None:
        await update.message.reply_text(
            f"❌ لا توجد مهمة بالرقم {task_id}."
        )
        return

    db.update_task(task_id, active=False)
    await update.message.reply_text(
        "✅ تم إيقاف المهمة:\n\n"
        f"🆔 ID: {task_id}\n"
        f"📌 العنوان: {task['title']}\n"
        f"✅ نشطة: لا"
    )
    logger.info("Task switched off: id=%d by admin %d", task_id, user_id)


# ── Admin: Remove Channel ────────────────────────────────────────────

async def remove_channel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Remove a mandatory subscription channel by slug. Admin only.

    Usage: /removechannel slug
    Example: /removechannel main
    """
    user_id = update.effective_user.id
    if not is_admin(user_id):
        subscribed, missing = await check_subscription_access(
            context.bot, user_id
        )
        if not subscribed:
            lock_user(user_id)
            text, markup = _build_missing_message(missing)
            await update.message.reply_text(text, reply_markup=markup)
            return
        unlock_user(user_id)
        await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return

    slug = update.message.text.replace("/removechannel", "", 1).strip()

    if not slug:
        await update.message.reply_text(
            "❌ صيغة خاطئة. استخدم:\n"
            "/removechannel slug\n\n"
            "مثال:\n"
            "/removechannel main"
        )
        return

    if slug not in CHANNELS:
        await update.message.reply_text(
            f"❌ القناة بالـslug '{slug}' غير موجودة."
        )
        return

    removed = CHANNELS.pop(slug)
    db.delete_channel(slug)

    await update.message.reply_text(
        "✅ تم حذف القناة:\n\n"
        f"📌 Slug: {removed.slug}\n"
        f"🆔 ID: {removed.channel_id}\n"
        f"📛 Username: @{removed.username}\n"
        f"📝 Title: {removed.title}"
    )
    logger.info("Channel removed: %s (id=%d) by admin %d", slug, removed.channel_id, user_id)


# NOTE: The legacy remove_channel handler is retained for backward-compatible
# unit tests.  The interactive /removechannel ConversationHandler below
# replaces it in the running bot.


async def removechannel_start(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Entry point for /removechannel.  Handles both direct and interactive.

    /removechannel <slug>  → direct deletion (legacy behaviour).
    /removechannel         → interactive inline-button workflow.
    admin_panel:remove     → interactive inline-button workflow (from panel).
    """
    user_id = update.effective_user.id
    if not is_admin(user_id):
        subscribed, missing = await check_subscription_access(
            context.bot, user_id
        )
        if not subscribed:
            lock_user(user_id)
            text, markup = _build_missing_message(missing)
            if update.callback_query:
                await update.callback_query.answer()
                await update.callback_query.edit_message_text(
                    text, reply_markup=markup
                )
            else:
                await update.message.reply_text(text, reply_markup=markup)
            return ConversationHandler.END
        unlock_user(user_id)
        if update.callback_query:
            await update.callback_query.answer()
            await update.callback_query.edit_message_text(
                "⛔ هذا الأمر للمشرفين فقط."
            )
        else:
            await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return ConversationHandler.END

    # ── Direct deletion (legacy path) — only for text commands ─────
    if not update.callback_query:
        slug = update.message.text.replace("/removechannel", "", 1).strip()
        if slug:
            if slug not in CHANNELS:
                await update.message.reply_text(
                    f"❌ القناة بالـslug '{slug}' غير موجودة."
                )
                return ConversationHandler.END

            removed = CHANNELS.pop(slug)
            db.delete_channel(slug)

            await update.message.reply_text(
                "✅ تم حذف القناة:\n\n"
                f"📌 Slug: {removed.slug}\n"
                f"🆔 ID: {removed.channel_id}\n"
                f"📛 Username: @{removed.username}\n"
                f"📝 Title: {removed.title}"
            )
            logger.info(
                "Channel removed: %s (id=%d) by admin %d",
                slug, removed.channel_id, user_id,
            )
            return ConversationHandler.END

    # ── Interactive flow ─────────────────────────────────────────────
    if not CHANNELS:
        if update.callback_query:
            await update.callback_query.answer()
            await update.callback_query.edit_message_text(
                "لا توجد قنوات إجبارية للحذف."
            )
        else:
            await update.message.reply_text(
                "لا توجد قنوات إجبارية للحذف."
            )
        return ConversationHandler.END

    buttons: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(
                text=f"📢 {ch.title} (@{ch.username})",
                callback_data=f"rmch:{ch.slug}",
            )
        ]
        for ch in CHANNELS.values()
    ]

    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            "🔄 اختر القناة المراد حذفها:",
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    else:
        await update.message.reply_text(
            "🔄 اختر القناة المراد حذفها:",
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    return REMOVECHANNEL_SELECT


async def removechannel_select(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Handle channel-selection callback → show confirmation."""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔ هذا الأمر للمشرفين فقط.")
        return ConversationHandler.END

    slug = query.data.split(":", 1)[1]

    if slug not in CHANNELS:
        await query.edit_message_text(
            "❌ القناة لم تعد متاحة. ربما تم حذفها بالفعل."
        )
        return ConversationHandler.END

    ch = CHANNELS[slug]
    buttons = [
        [
            InlineKeyboardButton(
                "✅ تأكيد الحذف", callback_data=f"rmch_yes:{slug}"
            ),
            InlineKeyboardButton(
                "❌ إلغاء", callback_data="rmch_no"
            ),
        ]
    ]
    await query.edit_message_text(
        f"⚠️ أنت على وشك حذف القناة:\n\n"
        f"📌 {ch.title}\n"
        f"📛 @{ch.username}\n"
        f"🆔 {ch.channel_id}\n\n"
        "هل أنت متأكد؟",
        reply_markup=InlineKeyboardMarkup(buttons),
    )
    return REMOVECHANNEL_CONFIRM


async def removechannel_confirm(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Handle confirmation callback → delete the channel."""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        await query.edit_message_text("⛔ هذا الأمر للمشرفين فقط.")
        return ConversationHandler.END

    slug = query.data.split(":", 1)[1]

    if slug not in CHANNELS:
        await query.edit_message_text(
            "❌ القناة لم تعد متاحة. ربما تم حذفها بالفعل."
        )
        return ConversationHandler.END

    removed = CHANNELS.pop(slug)
    db.delete_channel(slug)

    await query.edit_message_text(
        "✅ تم حذف القناة بنجاح:\n\n"
        f"📌 {removed.title}\n"
        f"📛 @{removed.username}\n"
        f"🆔 {removed.channel_id}"
    )
    logger.info(
        "Channel removed: %s (id=%d) via interactive flow",
        slug, removed.channel_id,
    )
    return ConversationHandler.END


async def removechannel_cancel_cb(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Handle cancel callback."""
    query = update.callback_query
    await query.answer()
    await query.edit_message_text("❌ تم الإلغاء. لم يتم حذف أي قناة.")
    return ConversationHandler.END


async def removechannel_cancel(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """Handle /cancel during the /removechannel conversation."""
    await update.message.reply_text("تم الإلغاء.")
    return ConversationHandler.END


# ── Subscription gate for protected bot commands ─────────────────────

async def subscription_gate(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Disabled duplicate gate — kept only as an importable symbol (MT-ADMIN-02).

    This function duplicated ``subscription_message_gate`` but was never
    registered in ``main()``: dead code.  It is intentionally a no-op so
    no duplicate lock/reply behaviour can ever run.  The live gate is
    ``subscription_message_gate`` (registered for private chats only).
    """
    return None


# ── Chat-member update handler ───────────────────────────────────────

_REQUIRED_CHANNEL_IDS: set[int] = set()


def _refresh_required_ids() -> None:
    """Rebuild the set of required channel IDs from the live CHANNELS dict."""
    global _REQUIRED_CHANNEL_IDS
    _REQUIRED_CHANNEL_IDS = {
        ch.channel_id for ch in get_required_channels()
    }


async def on_chat_member_update(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Detect when a user leaves or is removed from a required channel."""
    chat_member_update = update.chat_member
    if chat_member_update is None:
        return

    chat = chat_member_update.chat
    if chat is None or chat.id not in _REQUIRED_CHANNEL_IDS:
        return

    new_status = chat_member_update.new_chat_member.status
    user = chat_member_update.new_chat_member.user
    if user is None or user.id is None:
        return

    if new_status in ("left", "kicked"):
        lock_user(user.id)
        logger.info(
            "User %d left/was removed from required channel %d — locked",
            user.id,
            chat.id,
        )


# ── Subscription gate for non-command messages ────────────────────────

async def subscription_message_gate(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Block non-command messages from locked non-admin users.

    Registered in the same handler group as the ConversationHandler
    (group=1), so the ConversationHandler consumes anti-bot answer
    messages before this gate ever sees them.
    """
    if _non_private_chat(update):
        # MT-ADMIN-02: gating/lock messages must never reach groups or
        # channels — private chat only.
        return
    if update.message is None or update.message.text is None:
        return

    user_id = update.effective_user.id
    if is_admin(user_id):
        return

    subscribed, missing = await check_subscription_access(
        context.bot, user_id
    )
    if subscribed:
        unlock_user(user_id)
        return

    lock_user(user_id)
    text, markup = _build_missing_message(missing)
    await update.message.reply_text(text, reply_markup=markup)


# ── Clear legacy command menus on startup ──────────────────────────


async def clear_command_menus(application: Application) -> None:
    """Remove previously registered bot commands from Telegram.

    Clears commands from the default scope and every configured admin
    BotCommandScopeChat so old /addchannel /removechannel /listchannels
    entries no longer appear in the native command menu.
    """
    bot = application.bot

    # 1. Clear default scope
    await bot.delete_my_commands(scope=BotCommandScopeDefault())
    logger.info("Cleared default command menu")

    # 2. Clear each admin's per-chat scope
    for admin_id in ADMINS:
        await bot.delete_my_commands(
            scope=BotCommandScopeChat(chat_id=admin_id),
        )
        logger.info("Cleared command menu for admin %d", admin_id)


# ── Admin Channel Panel (inline buttons) ────────────────────────────


async def admin_command(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Admin-only /admin command that shows the channel management panel.

    MT-ADMIN-NEXT: private admin chat only — group/channel
    invocations stay silent before any authorization or rendering.
    """
    if _non_private_chat(update):
        return
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("⛔ هذا الأمر للمشرفين فقط.")
        return

    buttons = [
        [InlineKeyboardButton("➕ إضافة قناة أو مجموعة", callback_data="admin_panel:add")],
        [InlineKeyboardButton("🗑️ حذف قناة", callback_data="admin_panel:remove")],
        [InlineKeyboardButton("📋 عرض القنوات", callback_data="admin_panel:list")],
    ]
    await update.message.reply_text(
        "⚙️ إدارة القنوات",
        reply_markup=InlineKeyboardMarkup(buttons),
    )
    logger.info("Admin panel opened by admin %d", user_id)


async def admin_panel_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Handle admin panel callbacks (add, remove, list).

    MT-ADMIN-NEXT: private admin chat only — a press from a group or
    channel answers NOTHING (no callback answer, no read, no write)
    before any authorization, so the panel family is silent outside
    private chats.
    """
    if _non_private_chat(update):
        return
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    if not is_admin(user_id):
        await query.edit_message_text("⛔ هذا الأمر للمشرفين فقط.")
        return

    action = query.data.split(":", 1)[1]

    if action == "remove":
        # Route to the interactive removechannel workflow.
        await removechannel_start(update, context)
    elif action == "list":
        if not CHANNELS:
            await query.edit_message_text(
                "📭 لا توجد قنوات اشتراك إجباري حالياً."
            )
            return

        lines = ["📋 *قنوات الاشتراك الإجباري:*\n"]
        for ch in CHANNELS.values():
            required_text = "نعم" if ch.required else "لا"
            lines.append(
                f"📌 *{ch.title}*\n"
                f"   slug: `{ch.slug}`\n"
                f"   ID: `{ch.channel_id}`\n"
                f"   username: @{ch.username}\n"
                f"   required: {required_text}\n"
            )

        await query.edit_message_text(
            "\n".join(lines), parse_mode="Markdown"
        )
        logger.info("Channels listed by admin %d via panel", user_id)


# ── WispByte single-entry runtime ─────────────────────────────────
# WispByte starts the project with `python bot.py` only — it does not run
# the Procfile. This process must therefore serve the Mini App over HTTP
# (0.0.0.0:$PORT, Waitress) *and* keep the Telegram bot polling, without
# a second server or process manager.

_SINGLE_ENTRY_RUNNING = False


def create_mini_app() -> Flask:
    """Create the Flask application that serves the Mini App static files.

    Serves ``miniapp/index.html`` at ``/`` and all static assets (CSS, JS,
    images) under ``/<path>``.  The production Task pipeline endpoints
    (MT-TASK-03) are registered here so the WispByte single-entry
    process serves the Tasks page API as well.
    """
    from task_routes import tasks_bp
    # MT-ADMIN-25: user withdrawal API (methods + create).
    from withdrawal_routes import withdrawal_bp
    # MT-ADMIN-28: user deposit API (methods + pending intent).
    from deposit_routes import deposit_bp
    # Production social accounts API (YouTube OAuth, accounts list).
    from social_routes import social_bp

    mini_app = Flask(__name__)
    mini_app.register_blueprint(tasks_bp)
    mini_app.register_blueprint(withdrawal_bp)
    mini_app.register_blueprint(deposit_bp)
    mini_app.register_blueprint(social_bp)
    miniapp_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "miniapp"
    )

    @mini_app.route("/")
    def mini_app_index():
        """Serve the Mini App entry point."""
        return send_from_directory(miniapp_dir, "index.html")

    @mini_app.route("/<path:path>")
    def mini_app_static(path):
        """Serve static assets (CSS, JS, images, etc.)."""
        return send_from_directory(miniapp_dir, path)

    return mini_app


def create_mini_app_server(host: str = "0.0.0.0", port: "int | None" = None):
    """Create and bind the Waitress production WSGI server for the Mini App.

    Reads ``PORT`` from the environment (default ``5000``) unless *port* is
    given, and binds ``0.0.0.0`` as required by WispByte. The socket is bound
    during creation, so an ``OSError`` (e.g. address already in use) is
    raised immediately — deterministic startup-error reporting before any
    Telegram resource is created. Use ``server.run()`` to start accepting
    requests and ``server.close()`` for a clean shutdown.
    """
    if port is None:
        port = int(os.environ.get("PORT", 5000))
    return create_server(create_mini_app(), host=host, port=port)


def _handle_shutdown_signal(signum, frame) -> None:
    """Turn OS shutdown signals into a graceful single-entry shutdown.

    Raised on the main thread while ``server.run()`` is executing. Waitress
    catches ``KeyboardInterrupt``/``SystemExit`` and stops accepting requests,
    which lands in ``run_single_entry()``'s teardown: the Telegram lifecycle
    is stopped and the HTTP socket is closed, in that order.
    """
    logger.info(
        "Shutdown signal received (%s) — stopping Mini App HTTP server and Telegram bot",
        signum,
    )
    raise KeyboardInterrupt


async def _stop_telegram_application(application: Application) -> None:
    """Stop the Telegram application in ``run_polling``'s teardown order.

    Mirrors ``Application.__run``: ``updater.stop`` → ``stop`` → ``post_stop``
    → ``shutdown`` → ``post_shutdown``, each step guarded so a failure in one
    step never prevents the others — no PTB resources are left hanging.
    """
    try:
        if application.updater is not None and application.updater.running:
            await application.updater.stop()
    except Exception:
        logger.exception("Error while stopping Telegram updater")
    try:
        if application.running:
            await application.stop()
            if application.post_stop:
                await application.post_stop(application)
    except Exception:
        logger.exception("Error while stopping Telegram application")
    try:
        await application.shutdown()
        if application.post_shutdown:
            await application.post_shutdown(application)
    except Exception:
        logger.exception("Error while shutting down Telegram application")


def _run_telegram_bot(application: Application, stop_event: threading.Event) -> None:
    """Run the Telegram bot in a controlled background execution context.

    Mirrors ``Application.run_polling``'s internal lifecycle on a dedicated
    event loop:

    ``initialize → post_init → updater.start_polling → start`` … wait for
    *stop_event* … ``updater.stop → stop → post_stop → shutdown → post_shutdown``

    Polling errors are forwarded to the application's registered error
    handlers via the same ``error_callback`` wrapper ``run_polling`` installs.
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    # MT-ADMIN-03: bridge the server-side manual-proof submission flow
    # (Waitress/Flask thread) onto this bot loop.  Fresh pending claims
    # are scheduled with run_coroutine_threadsafe and delivered through
    # AdminNotifier — config.ADMINS private chats only, never the
    # required channels/groups.  Bound only while this bot loop runs
    # and unbound in the finally below, so a stopped bot never sends.
    async def _send_text(chat_id: int, text: str) -> None:
        await application.bot.send_message(chat_id=chat_id, text=text)

    async def _send_markup(chat_id: int, text: str, reply_markup) -> int:
        message = await application.bot.send_message(
            chat_id=chat_id, text=text, reply_markup=reply_markup
        )
        return message.message_id

    def _schedule_notification(coroutine):
        return asyncio.run_coroutine_threadsafe(coroutine, loop)

    # MT-ADMIN-06: the support flow shares the SAME AdminNotifier —
    # ADMINS private chats only, never channels/groups.
    _admin_notifier = AdminNotifier(_send_text, markup_send=_send_markup)
    manual_proof_inbox.bind(
        _admin_notifier,
        _schedule_notification,
    )
    support_service.bind(_admin_notifier)
    # Withdrawal submission notices share the SAME AdminNotifier and
    # loop scheduler (ADMINS private chats only) — bound only while
    # this bot loop runs.
    withdrawal_notifications.bind(_admin_notifier, _schedule_notification)
    # Task requests created from the Mini App («إضافة مهمة ➕») share
    # the SAME AdminNotifier and loop scheduler — ADMINS private chats
    # only, bound only while this bot loop runs.
    task_request_notifications.bind(
        _admin_notifier, _schedule_notification
    )

    def _error_callback(exc: TelegramError) -> None:
        application.create_task(application.process_error(error=exc, update=None))

    async def _lifecycle() -> None:
        try:
            await application.initialize()
            if application.post_init:
                await application.post_init(application)
            await application.updater.start_polling(
                error_callback=_error_callback,
                # MT-ADMIN-02: chat_member updates are excluded unless
                # requested explicitly — the ChatMemberHandler would
                # otherwise never receive them.
                allowed_updates=Update.ALL_TYPES,
            )
            await application.start()
            logger.info("Telegram bot polling started (background thread)")
            while not stop_event.is_set():
                await asyncio.sleep(0.5)
        finally:
            logger.info("Telegram bot stopping...")
            await _stop_telegram_application(application)

    try:
        loop.run_until_complete(_lifecycle())
    except Exception:
        logger.exception("Telegram bot background thread error")
    finally:
        # MT-ADMIN-03: detach the notification bridge before the loop
        # goes away so late submissions fail soft (inbox unbound)
        # instead of scheduling onto a dead loop.  MT-ADMIN-06: the
        # support service unbinds with the inbox so a stopped bot
        # never notifies.
        support_service.unbind()
        manual_proof_inbox.unbind()
        withdrawal_notifications.unbind()
        task_request_notifications.unbind()
        try:
            loop.run_until_complete(loop.shutdown_asyncgens())
        finally:
            asyncio.set_event_loop(None)
            loop.close()


def run_single_entry(application: Application) -> None:
    """Run the Mini App HTTP server and the Telegram bot from this process.

    WispByte's Startup Command is ``python bot.py`` and it does not execute
    the Procfile, so this one process provides both:

    * **HTTP** — Waitress serves the Mini App on ``0.0.0.0:$PORT`` in the
      main thread; this is the listener WispByte's reverse proxy routes to.
    * **Telegram** — polling runs in a background thread with PTB's full
      lifecycle, stopped cleanly via *stop_event*.

    The HTTP listener is bound **before** any Telegram resource is created:
    if the bind fails, ``OSError`` propagates immediately (logged clearly)
    and nothing else has been started. Exactly one HTTP server is created
    per process — a concurrent second call raises ``RuntimeError``.
    """
    global _SINGLE_ENTRY_RUNNING
    if _SINGLE_ENTRY_RUNNING:
        raise RuntimeError(
            "Mini App HTTP server is already running — duplicate startup prevented"
        )
    _SINGLE_ENTRY_RUNNING = True
    try:
        # 1. Bind the HTTP listener first: fail fast, fail clearly.
        try:
            server = create_mini_app_server()
        except OSError as exc:
            logger.error(
                "Mini App HTTP server failed to bind on 0.0.0.0:%s — %s",
                os.environ.get("PORT", "5000"),
                exc,
            )
            raise
        logger.info(
            "Mini App server bound on %s:%s",
            server.effective_host,
            server.effective_port,
        )

        # 2. Telegram bot: controlled background execution context.
        stop_event = threading.Event()
        bot_thread = threading.Thread(
            target=_run_telegram_bot,
            args=(application, stop_event),
            name="telegram-bot",
        )

        # 3. Graceful OS-signal handling while the main thread serves HTTP.
        previous_handlers: dict = {}
        if threading.current_thread() is threading.main_thread():
            for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGABRT):
                previous_handlers[sig] = signal.signal(sig, _handle_shutdown_signal)

        thread_started = False
        try:
            bot_thread.start()
            thread_started = True
            # Waitress owns the main thread until a shutdown signal arrives;
            # its run() converts KeyboardInterrupt/SystemExit into a clean
            # return, landing in the teardown below.
            server.run()
        finally:
            for sig, handler in previous_handlers.items():
                signal.signal(sig, handler)
            # Ordered shutdown: Telegram first, then the HTTP listener.
            logger.info("HTTP server stopped. Shutting down Telegram bot...")
            stop_event.set()
            if thread_started:
                bot_thread.join(timeout=10)
                if bot_thread.is_alive():
                    logger.warning(
                        "Telegram bot thread did not stop within timeout"
                    )
            try:
                server.close()
            except Exception:
                logger.exception("Error while closing the Mini App HTTP server")
    finally:
        _SINGLE_ENTRY_RUNNING = False


def main() -> None:
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN environment variable is not set")

    # Initialize SQLite database and load persisted channels
    db.init_db()
    db.load_channels()
    _refresh_required_ids()

    app = ApplicationBuilder().token(token).build()

    # Clear legacy command menus registered by earlier bot versions.
    app.post_init = clear_command_menus

    conv_handler = ConversationHandler(
        entry_points=[
            # MT-ADMIN-02: onboarding starts in private chats only.
            CommandHandler("start", start, filters=filters.ChatType.PRIVATE),
        ],
        states={
            ANTI_BOT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, check_answer),
            ],
            ANTI_BOT_BLOCKED: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, _blocked),
            ],
            LANGUAGE_SELECT: [
                CallbackQueryHandler(
                    language_selected, pattern=LANGUAGE_CALLBACK_ANY
                ),
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, language_prompt_again
                ),
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    # 1. Detect channel departures immediately.
    #    MT-ADMIN-02: registered unconditionally — even when zero channels
    #    are configured at startup — so chat_member updates are always
    #    handled as soon as required channels exist.  The handler itself
    #    ignores chats that are not required channels.
    app.add_handler(
        ChatMemberHandler(
            on_chat_member_update,
            ChatMemberHandler.CHAT_MEMBER,
            block=False,
        ),
        group=0,
    )

    # 2. Anti-bot conversation (entry: /start).
    app.add_handler(conv_handler, group=1)

    # 2b. Stale/invalid language callbacks.  Same group, right after the
    #     conversation, so exactly one of them fires per update: the
    #     conversation consumes presses made while it awaits a choice,
    #     this handler safely answers presses made at any other time.
    app.add_handler(
        CallbackQueryHandler(
            language_callback_fallback, pattern=LANGUAGE_CALLBACK_ANY
        ),
        group=1,
    )

    # 3. Subscription gate for non-command messages.
    #    Same group as the ConversationHandler so only one fires per
    #    update: when the ConversationHandler matches (ANTI_BOT state)
    #    it consumes the update and the gate never fires for it.
    #    MT-ADMIN-02: private chats only — the gate must never reply in
    #    groups/channels.
    app.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
            subscription_message_gate,
        ),
        group=1,
    )

    # 4. Interactive /addchannel conversation (group 2, before other commands).
    #    Admin check + subscription gate are inside addchannel_start.
    #    Also accepts admin panel "Add" callback as entry point.
    addchannel_conv = ConversationHandler(
        entry_points=[
            CommandHandler("addchannel", addchannel_start),
            CallbackQueryHandler(
                addchannel_start, pattern="^admin_panel:add$"
            ),
        ],
        states={
            ADDCHANNEL_USERNAME: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, addchannel_username
                ),
            ],
            ADDCHANNEL_TITLE: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, addchannel_title
                ),
            ],
        },
        fallbacks=[CommandHandler("cancel", addchannel_cancel)],
    )

    # 5. Interactive /removechannel conversation (group 3).
    #    Legacy /removechannel <slug> is handled inside removechannel_start.
    #    Also accepts admin panel "Remove" callback as entry point.
    removechannel_conv = ConversationHandler(
        entry_points=[
            CommandHandler("removechannel", removechannel_start),
        ],
        states={
            REMOVECHANNEL_SELECT: [
                CallbackQueryHandler(
                    removechannel_select, pattern=r"^rmch:"
                ),
            ],
            REMOVECHANNEL_CONFIRM: [
                CallbackQueryHandler(
                    removechannel_confirm, pattern=r"^rmch_yes:"
                ),
                CallbackQueryHandler(
                    removechannel_cancel_cb, pattern=r"^rmch_no$"
                ),
            ],
        },
        fallbacks=[CommandHandler("cancel", removechannel_cancel)],
    )

    # Register add/remove conversations in group 0 (BEFORE the anti-bot
    # ConversationHandler in group 1).  This ensures admin-panel callback
    # queries (admin_panel:add / admin_panel:remove) are matched by these
    # ConversationHandler entry points before the anti-bot handler can
    # intercept them when per_callback_query is not supported.
    app.add_handler(addchannel_conv, group=0)
    app.add_handler(removechannel_conv, group=0)
    app.add_handler(CommandHandler("listchannels", list_channels), group=0)
    # Admin-only task creation (telegram_channel).  Authorization is
    # enforced inside add_task; non-admins get an admin-only reply.
    # Not added to the BotCommand menu, same as the other admin commands.
    app.add_handler(CommandHandler("addtask", add_task), group=0)
    app.add_handler(CommandHandler("listtasks", list_tasks), group=0)
    app.add_handler(CommandHandler("offtask", off_task), group=0)
    # MT-ADMIN-04: /reviews — admin pending manual-review queue.
    #    Private chat only; authorization enforced inside the command
    #    (admin gate for access, task approver for the actual review).
    app.add_handler(CommandHandler(
        "reviews", admin_review_queue.reviews_command,
    ), group=0)
    # MT-ADMIN-06: /support — ONE deterministic entry point:
    #    private admin -> admin support queue; private non-admin ->
    #    user support flow (category selection).  Group/channel
    #    invocations are silent (isolation enforced inside).
    app.add_handler(CommandHandler(
        "support", support_service.support_command,
    ), group=0)
    # User withdrawal flow — private chat ONLY (group/channel
    #    invocations silent).  Identity comes from effective_user and
    #    every mutation delegates to WithdrawalService (one atomic
    #    transaction); no client-supplied user id is ever accepted.
    app.add_handler(CommandHandler(
        "withdraw", withdrawal_user.withdraw_command,
    ), group=0)
    # MT-ADMIN-08: payment-method management — private admin chat ONLY.
    #    /paymethods panel; bare /addpm opens the interactive wizard,
    #    /addpm <form> + /editpm <id> | <form> keep the stateless
    #    pipe-form convention (same as /addchannel).  Authorization is
    #    enforced inside every handler; group/channel invocations stay
    #    silent (MT-ADMIN-02 isolation).
    app.add_handler(CommandHandler(
        "paymethods", payment_method_admin.paymethods_command,
    ), group=0)
    app.add_handler(CommandHandler(
        "addpm", payment_method_admin.add_pm_command,
    ), group=0)
    app.add_handler(CommandHandler(
        "editpm", payment_method_admin.edit_pm_command,
    ), group=0)
    app.add_handler(CommandHandler(
        "repairdepositminimums",
        payment_method_admin.repair_deposit_minimums_command,
    ), group=0)
    # MT-ADMIN-26: /setrate — authoritative manual EGP-per-USDT rate.
    #    Private admin chat ONLY; authorization is enforced inside the
    #    handler (config.is_admin) and the rate is validated by the
    #    existing rate_quote contract before anything is persisted.
    #    Not added to the BotCommand menu, same as the other admin
    #    commands.  No client/Mini App path can ever set the rate.
    app.add_handler(CommandHandler(
        "setrate", rate_admin.setrate_command,
    ), group=0)
    # MT-ADMIN-27: /withdrawals — admin review queue for pending
    #    payout requests.  Private admin chat ONLY; authorization is
    #    enforced inside the handler (config.is_admin) and every
    #    mutation delegates to the existing WithdrawalService.
    #    Not added to the BotCommand menu, same as the other admin
    #    commands.
    app.add_handler(CommandHandler(
        "withdrawals", withdrawal_admin.withdrawals_command,
    ), group=0)
    # MT-ADMIN-31: /deposits — admin review queue for manual deposit
    #    proof screenshots.  Private admin chat ONLY; authorization
    #    is enforced inside the handler (config.is_admin) and the
    #    sole financial credit path is the existing trusted manual
    #    review service — a screenshot alone credits nothing.  Not
    #    added to the BotCommand menu, same as the other admin
    #    commands.
    app.add_handler(CommandHandler(
        "deposits", deposit_proof_admin.deposits_command,
    ), group=0)
    # Mini App «إضافة مهمة» — user task requests review queue.
    #    /taskrequests — private admin chat ONLY; authorization is
    #    enforced inside the handler (config.is_admin) and every
    #    decision delegates to task_request_store + the canonical
    #    task_creation service (never a second creation path).  Not
    #    added to the BotCommand menu, same as the other admin
    #    commands.
    app.add_handler(CommandHandler(
        "taskrequests", task_request_admin.taskrequests_command,
    ), group=0)

    # MT-ADMIN-32: /control — Admin Control Center foundation.  A
    #    thin, READ-ONLY dashboard over the existing stores (aggregate
    #    counts + current rate status) with navigation buttons to the
    #    existing admin surfaces.  Private admin chat ONLY;
    #    authorization is enforced inside the handler (config.is_admin)
    #    and no financial state of any kind is mutated.  Not added to
    #    the BotCommand menu, same as the other admin commands.
    app.add_handler(CommandHandler(
        "control", admin_control.control_command,
    ), group=0)
    # MT-ADMIN-05: wizard free-text answers (title, target,
    #    instructions, reward, repeat hours).  Registered LAST in
    #    group 0 so the add/remove-channel conversations consume their
    #    own text first; the handler itself stays silent unless the
    #    sender is an admin with an open draft on a text-input step.
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
        admin_task_wizard.wizard_text_input,
    ), group=0)

    # MT-ADMIN-06: support text input (user message after category
    #    selection, or an admin's persisted reply).  Registered in its
    #    OWN handler group so the group-0 wizard catch-all cannot
    #    shadow it (and vice versa); the body stays silent unless the
    #    sender's own persisted support state matches, so ordinary
    #    chat, the anti-bot conversation and the wizard are unaffected.
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
        support_service.support_text_input,
    ), group=2)

    # MT-ADMIN-32/39: admin_control free-text catch-alls, registered
    # STATICALLY here instead of lazily from inside control_callback.
    # Adding a handler during Application.process_update() mutates
    # application.handlers while the update fetcher is iterating it
    # (RuntimeError: dictionary changed size during iteration), which
    # silently kills the _update_fetcher task — updates keep being
    # ACKed by getUpdates but are never processed until restart.
    # Each handler is self-gated (silent unless the sender is an admin
    # with matching state), so early groups are unaffected.
    #   group 3 — task-edit free text (title/target/instructions/...)
    #   group 6 — /addtask admin text input
    #   group 7 — broadcast text input
    #   group 8 — settings text input
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
        admin_control.task_edit_text_input,
    ), group=3)
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
        admin_control.admin_add_text_input,
    ), group=6)
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
        admin_control.broadcast_text_input,
    ), group=7)
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
        admin_control.settings_text_input,
    ), group=8)
    # Mini App «إضافة مهمة»: admin free text for a pending treq:
    #    prompt (reject reason / return note / field edit).  Registered
    #    STATICALLY in its OWN group (same rationale as groups 3/6/7/8)
    #    and self-gated — silent unless the sender is an admin holding
    #    a treq: input state, so every earlier text handler is unaffected.
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
        task_request_admin.task_request_text_input,
    ), group=9)

    # MT-ADMIN-08: payment-method wizard free-text answers (manual
    #    asset/network entry, name, provider, destination, notes).
    #    Registered STATICALLY in its OWN group (same rationale as
    #    groups 2/3/6/7/8/9) and self-gated — silent unless the sender
    #    is an admin holding a live /addpm or /editpm wizard state on
    #    a text-input step, so every earlier text handler is unaffected.
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
        payment_method_admin.wizard_text_input,
    ), group=10)

    # 6. Verify callback (re-checks all channels, unlocks if subscribed).
    app.add_handler(CallbackQueryHandler(
        verify_subscription, pattern="^verify_subscription$",
    ), group=4)

    # 7. Admin panel: add/remove/list callbacks + /admin command.
    #    /admin is NOT added to the BotCommand menu.
    app.add_handler(CallbackQueryHandler(
        admin_panel_callback, pattern=r"^admin_panel:(add|remove|list)$",
    ), group=5)
    app.add_handler(CommandHandler("admin", admin_command), group=5)

    # 8. MT-ADMIN-03: admin manual-proof inbox — Approve/Reject
    #    callbacks on the notification messages.  Authorization is
    #    entirely task-specific (task_data.approver) inside the
    #    handler; ADMINS membership grants no decision authority.
    app.add_handler(CallbackQueryHandler(
        manual_proof_inbox.proof_callback_handler, pattern=r"^mproof:",
    ), group=5)

    # MT-ADMIN-04: queue Review buttons + page navigation (discovery
    #    only — decisions still flow through the mproof handlers above
    #    into ManualReviewService.decide with task-specific authority.
    app.add_handler(CallbackQueryHandler(
        admin_review_queue.review_queue_callback, pattern=r"^mr(view|vp):",
    ), group=5)

    # MT-ADMIN-05: task-creation wizard buttons (family/provider/
    #    action/verification/approver/repeat/edit/confirm/cancel).
    #    The draft id in the callback is a lookup pointer only — the
    #    handler re-reads actor, ownership and state from the DB.
    app.add_handler(CallbackQueryHandler(
        admin_task_wizard.wizard_callback, pattern=r"^atw:",
    ), group=5)

    # MT-ADMIN-06: user category buttons + admin queue/open/reply/
    #    close/cancel/page callbacks.  Payloads carry only an opaque
    #    category or positive inquiry/page id — every authorization
    #    fact and the recipient are re-read server-side.
    app.add_handler(CallbackQueryHandler(
        support_service.support_category_callback, pattern=r"^supcat:",
    ), group=5)
    app.add_handler(CallbackQueryHandler(
        support_service.support_admin_callback, pattern=r"^sup:",
    ), group=5)

    # MT-ADMIN-08: payment-method buttons (list/help/edit/state-
    #    toggle/delete-confirm).  Payloads are pm:<op>[:<positive
    #    id>] lookup pointers only — actor authorization and every
    #    field are re-read server-side from SQLite.
    app.add_handler(CallbackQueryHandler(
        payment_method_admin.payment_method_callback, pattern=r"^pm:",
    ), group=5)

    # MT-ADMIN-27: withdrawal review buttons (list/detail/confirm/
    #    complete/reject).  Payloads are wd:<op>:<request id> lookup
    #    pointers only — actor authorization and every fact are
    #    re-read server-side, and the sole mutation path is the
    #    existing WithdrawalService.
    app.add_handler(CallbackQueryHandler(
        withdrawal_admin.withdrawal_callback, pattern=r"^wd:",
    ), group=5)

    # MT-ADMIN-31: deposit proof review buttons (list/detail/
    #    confirm/approve/reject).  Payloads are dp:<op>:<proof id>
    #    lookup pointers only — actor authorization and every fact
    #    are re-read server-side; the screenshot is evidence for the
    #    admin's manual verification and never credits by itself.
    app.add_handler(CallbackQueryHandler(
        deposit_proof_admin.proof_callback, pattern=r"^dp:",
    ), group=5)

    # Mini App «إضافة مهمة»: user task-request review buttons
    #    (list/view/edit/approve/return/reject).  Payloads are
    #    treq:<op>[:<positive id>] lookup pointers only — the admin
    #    gate (config.is_admin) and every fact are re-read server-side,
    #    and approval flows through the ONE canonical creation service.
    app.add_handler(CallbackQueryHandler(
        task_request_admin.task_request_callback, pattern=r"^treq:",
    ), group=5)

    # MT-ADMIN-32/33: control-center navigation buttons (attention-
    #    first queues first).  Payloads are ctl:<surface> fixed surface
    #    identifiers only — the callback re-checks config.is_admin
    #    server-side and DELEGATES to the existing command handlers
    #    (listtasks/reviews/withdrawals/deposits/paymethods/setrate);
    #    it renders no data of its own and never
    #    touches any financial state (ledger, holds, deposits,
    #    withdrawals, payment methods, rates or tasks), and never
    #    duplicates the wd:/dp: families.
    app.add_handler(CallbackQueryHandler(
        admin_control.control_callback, pattern=r"^ctl:",
    ), group=5)

    # Register the Mini App menu button (Open button) via post_init.
    # We chain it with the admin command menu setup.
    original_post_init = app.post_init

    async def _combined_post_init(application: Application) -> None:
        if original_post_init is not None:
            await original_post_init(application)
        await setup_menu_button(application)

    app.post_init = _combined_post_init

    logger.info("Bot is starting...")
    # WispByte runs only `python bot.py` — no Procfile, no second process.
    # This process serves the Mini App HTTP on 0.0.0.0:$PORT (Waitress, main
    # thread) while Telegram polling runs in a controlled background thread.
    run_single_entry(app)


# ── Telegram Mini App Menu Button ───────────────────────────────────


async def setup_menu_button(application: Application) -> None:
    """Configure the official Telegram Menu Button (Web App) globally.

    Uses Bot.set_chat_menu_button (without chat_id) to set a MenuButtonWebApp
    with text "Open" that opens the configured MINI_APP_URL.  Telegram places
    this button natively in the composer area for all bot users — no custom
    keyboard is created.
    """
    mini_app_url = get_mini_app_url()
    menu_button = MenuButtonWebApp(
        text="Open",
        web_app=WebAppInfo(url=mini_app_url),
    )
    bot = application.bot
    await bot.set_chat_menu_button(
        menu_button=menu_button,
    )
    logger.info("Set global Mini App menu button → %s", mini_app_url)


if __name__ == "__main__":
    main()
