#!/usr/bin/env python3
"""Owner-management lifecycle + frontend UX for published task requests.

Phase 17 (owner management): a published task's requester can PAUSE / RESUME /
LOGICALLY ARCHIVE their own request from the Mini App without touching funding,
ledger, claims, published-task rows, or any DB schema.  State is recorded as
append-only history events on the already-approved ``user_task_requests`` row:

* ``"paused"`` — NEW participation from all entry points (catalog discovery,
  worker start, worker submit) is blocked with a 409; reviewer surfaces keep
  working so existing claims/reviews stay accessible.
* ``"archived"`` — the request is hidden from the owner's Mini App list and
  from catalog discovery (404 to workers), but the row/funding/ledger/claim data
  stay intact.

The ``request.status`` column keeps its schema-constrained value (``approved``),
so these operations require NO migration and alter NO financial or task state.

The public API (see task_routes) uses this module exclusively:

* ``participation_block(task_id)`` — ownership-blind predicate used by the
  discovery surface and worker entry points; returns ``None``, ``"paused"``, or
  ``"archived"``.
* ``request_is_paused(req)`` / ``request_is_archived(req)`` — read-only views
  of the append-only history, also surfaced to the Mini App as the ``paused`` /
  ``archived`` response fields.
* ``_owner_published_pair(conn, user_id, published_task_id)`` — server-side
  ownership lookup returning ``(request, task_id)`` or ``(None, None)``.
* ``apply_edit / apply_pause / apply_resume / apply_archive`` — the mutating
  owner endpoints, each keyed on ownership (and, for edits, on whether the
  request is paused).

TaskRequestError is the only exception path; every code in task_routes maps
its ``str(exc)`` to a bilingual user-facing response.  The *ENGLISH suffixed
messages are stable identity keys used in equality checks there; they should not
change without a matching routes change.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import sqlite3

logger = logging.getLogger(__name__)


# ── Exceptions / stable message identifiers ───────────────────────────────
# These are used by :mod:`task_routes` in equality checks, so they must stay
# stable.  The non-ENGLISH fields are the display strings surfaced to the
# Mini App in the relevant language (Arabic here, matching the codebase).

class TaskRequestError(Exception):
    """Raised by owner-management mutators when a guard is lost.

    Translated by ``task_routes`` to a user-facing response code.  The payload
    is the English identity string that routes key off — keep it stable.
    """


# Stable identity keys (English).  Routes compare ``str(exc)`` to these.
MSG_NOT_OWNER_ENGLISH = "not_the_owner_of_this_published_task"
MSG_CANNOT_EDIT_PAUSED_ENGLISH = "cannot_edit_while_paused"
MSG_INVALID_FIELD_ENGLISH = (
    "Only title and description may be edited by the owner.  "
    "Provider, action and target_ref edits are an admin-review decision "
    "and can never be changed here.  //index.html"
    " يمكن تعديل العنوان والوصف فقط من قبل صاحب المهمة؛ "
    "تعديلات المنصة والإجراء والمرجع هي قرار إداري ولا يمكن تغييرها هنا."
)
MSG_INVALID_PAYLOAD_ENGLISH = "invalid_edit_payload"


# ── Persistence helpers (delegated to task_request_store) ─────────────────
# The mutating writes below rely on ``task_request_store`` having the Phase-17
# helpers: ``owner_edit_payload``, ``owner_append_history_event``,
# ``get_request_by_published_task``, and the ``_COLUMNS`` query shape.  When
# those are not yet present in the live store (the Phase-18 build happens in
# stages), the module degrades gracefully: every public function still exists
# and raises the right TaskRequestError on the right condition, but the write
# path raises TaskRequestError("store_not_yet_ready") instead of mutating.
# This lets the *frontend* of this feature ship/serve before the backend write
# helpers land, without inventing them here.

try:
    import task_request_store as _store
except Exception:  # pragma: no cover - degenerate import failure
    _store = None  # type: ignore[assignment]


def _require_store() -> object:
    if _store is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    return _store


# ── Read-only lifecycle views (participation gate + Mini App flags) ───────

def participation_block(task_id: int) -> str | None:  # noqa: A003
    """Whether NEW participation on a published task should be blocked.

    Returns ``None`` (open), ``"paused"``, or ``"archived"``.  Ownership-blind:
    a worker learns only the state, never who owns the task.
    """
    if not isinstance(task_id, int) or task_id <= 0:
        return None
    store = _require_store()
    req = getattr(store, "get_request_by_published_task", None)
    if req is None:
        return None
    row = req(task_id)
    if row is None:
        return None
    return _lifecycle_state(row)


def request_is_paused(req) -> bool:
    """Read-only view: is this (approved) request currently owner-paused."""
    if req is None:
        return False
    return _lifecycle_state(req) == "paused"


def request_is_archived(req) -> bool:
    """Read-only view: is this (approved) request logically hidden from the
    owner's list / from catalog discovery."""
    if req is None:
        return False
    return _lifecycle_state(req) == "archived"


def _lifecycle_state(req) -> str:  # private
    """Derive paused/archived/running from the append-only history.

    The request ``status`` column keeps its approved value — these are
    operational markers only.  When the store helpers are absent the state is
    always ``"running"`` (i.e. no-op), which is the safe conservative default
    while the backend write helpers are being landed.
    """
    store = _store
    if store is None:
        return "running"
    history = getattr(req, "history", None)
    if history is None or not isinstance(history, list):
        return "running"
    state = "running"
    for item in history:
        if not isinstance(item, dict):
            continue
        event = item.get("event")
        if event == "owner_pause":
            state = "paused"
        elif event == "owner_resume":
            state = "running"
        elif event == "owner_archive":
            state = "archived"
    return state


# ── Ownership lookup (used by owner_get_task + shared by mutators) ───────

def _owner_published_pair(conn, user_id: int, published_task_id: int):
    """Return ``(request, task_id)`` for the caller's OWN published request,
    or ``(None, None)`` when the task does not belong to them (or does not
    exist / isn't published under that id).

    Ownership is verified here: a foreign task is indistinguishable from
    "not found" for this caller.
    """
    store = _store
    if store is None:
        return (None, None)
    get = getattr(store, "get_request_by_published_task", None)
    if get is None:
        return (None, None)
    req = get(published_task_id)
    if req is None:
        return (None, None)
    if getattr(req, "user_id", None) != user_id:
        return (None, None)
    tid = getattr(req, "published_task_id", None)
    if not isinstance(tid, int):
        return (None, None)
    return (req, tid)


# ── Owner mutators (edit / pause / resume / archive) ─────────────────────

def apply_edit(
    conn, user_id: int, published_task_id: int, body: dict
):
    """Owner edits the title/description of their OWN published request.

    Provider, action and target_ref are never writable here (admin-review path
    only).  Edits are rejected while the request is paused.
    """
    store = _store
    if store is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    try:
        request, task_id = _owner_published_pair(conn, user_id, published_task_id)
    except Exception:  # noqa: S110
        logger.exception("owner_edit pair lookup failed")
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)

    if request is None or task_id is None:
        raise TaskRequestError(MSG_NOT_OWNER_ENGLISH)

    if _lifecycle_state(request) == "paused":
        raise TaskRequestError(MSG_CANNOT_EDIT_PAUSED_ENGLISH)

    allowed = {"title", "description"}
    rejected = set(body) - allowed
    if rejected:
        raise TaskRequestError(MSG_INVALID_FIELD_ENGLISH)

    title = body.get("title")
    description = body.get("description")
    if not title or not isinstance(title, str) or not title.strip():
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    if not description or not isinstance(description, str) or not description.strip():
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)

    payload = {"title": title.strip(), "description": description.strip()}
    # Keep the existing server-side shape for any fields we are not touching
    # (provider/action/target_ref/reward_units) untouched.
    existing = getattr(request, "payload", None)
    if isinstance(existing, dict):
        payload = {**existing, **payload}

    updated = getattr(store, "owner_edit_payload", None)
    if updated is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    result = updated(conn, getattr(request, "request_id", None), user_id, payload)
    if result is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    return result


def apply_pause(conn, user_id: int, published_task_id: int):
    """Owner pause (idempotent): re-pausing an already-paused request is a
    quiet success."""
    store = _store
    if store is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    request, _tid = _owner_published_pair(conn, user_id, published_task_id)
    if request is None or _tid is None:
        raise TaskRequestError(MSG_NOT_OWNER_ENGLISH)
    if _lifecycle_state(request) == "paused":
        return request
    append = getattr(store, "owner_append_history_event", None)
    if append is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    result = append(conn, getattr(request, "request_id", None), user_id, "owner_pause")
    if result is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    return result


def apply_resume(conn, user_id: int, published_task_id: int):
    """Owner resume (idempotent): resuming a running request is a quiet success."""
    store = _store
    if store is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    request, _tid = _owner_published_pair(conn, user_id, published_task_id)
    if request is None or _tid is None:
        raise TaskRequestError(MSG_NOT_OWNER_ENGLISH)
    if _lifecycle_state(request) == "running":
        return request
    append = getattr(store, "owner_append_history_event", None)
    if append is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    result = append(conn, getattr(request, "request_id", None), user_id, "owner_resume")
    if result is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    return result


def apply_archive(conn, user_id: int, published_task_id: int):
    """Owner logical archive (idempotent): hides the request from the owner's
    Mini App list and from catalog discovery.  No delete, no financial mutation.
    """
    store = _store
    if store is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    request, _tid = _owner_published_pair(conn, user_id, published_task_id)
    if request is None or _tid is None:
        raise TaskRequestError(MSG_NOT_OWNER_ENGLISH)
    if _lifecycle_state(request) == "archived":
        return request
    append = getattr(store, "owner_append_history_event", None)
    if append is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    result = append(conn, getattr(request, "request_id", None), user_id, "owner_archive")
    if result is None:
        raise TaskRequestError(MSG_INVALID_PAYLOAD_ENGLISH)
    return result
