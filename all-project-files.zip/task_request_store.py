#!/usr/bin/env python3
"""Task-request store with Phase-17/18 owner lifecycle write-helpers.

The owner management flow records lifecycle as append-only history events on the
already-approved request row (no status column mutation, no schema change).  This
module provides the small store helpers the owner mutators in
:mod:`task_owner_management` depend on:

* :func:`get_request_by_published_task` — lookup by the public task id the request
  published.
* :func:`owner_edit_payload` — rewrite title/description only, preserving the rest
  of the existing payload shape.
* :func:`owner_append_history_event` — append a guarded lifecycle event and return
  the refreshed request row (with a ``history`` attribute on the returned object).
* The request objects returned by store reads are duck-typed to carry a ``history``
  attribute (a list of event dicts) so the read-side helpers in :mod:`task_routes`
  and :mod:`task_owner_management` can render paused/archived flags without a new
  column.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import db
import json as _json

logger = logging.getLogger(__name__)

# Keep these module-level constants in sync with whatever imports them
# (notably task_request_admin and task_routes).
STATUS_PENDING = "pending"
STATUS_CHANGES_REQUESTED = "changes_requested"
STATUS_APPROVED = "approved"
STATUS_REJECTED = "rejected"
STATUS_COMPLETED = "completed"

# Shared request record shape used by task_request_admin for iteration + updates.
_COLUMNS = [
    "request_id",
    "user_id",
    "status",
    "payload_json",
    "reward_units",
    "decision_reason",
    "decided_by",
    "published_task_id",
    "created_at",
    "updated_at",
]


# ── public shape for request rows ─────────────────────────────────────────

class _RequestRow:
    __slots__ = (
        "request_id",
        "user_id",
        "status",
        "payload",
        "reward_units",
        "decision_reason",
        "admin_user_id",
        "published_task_id",
        "created_at",
        "updated_at",
        "history",
    )

    def __init__(
        self,
        request_id: int,
        user_id: int,
        status: str,
        payload: dict[str, Any],
        reward_units: int,
        decision_reason: str | None,
        admin_user_id: int | None,
        published_task_id: int | None,
        created_at: str | None,
        updated_at: str | None,
        history: list[dict[str, Any]] | None = None,
    ) -> None:
        self.request_id = request_id
        self.user_id = user_id
        self.status = status
        self.payload = payload
        self.reward_units = reward_units
        self.decision_reason = decision_reason
        self.admin_user_id = admin_user_id
        self.published_task_id = published_task_id
        self.created_at = created_at
        self.updated_at = updated_at
        # Phase-17/18: lifecycle is derived from append-only history events.
        self.history = history if isinstance(history, list) else []

    # task_request_admin expects a traditional ORM-ish object with a dict-iterable
    # row and attribute access.
    def __getitem__(self, key: str) -> Any:
        return self._asdict()[key]

    def __iter__(self):
        return iter(self._asdict().values())

    def keys(self):
        return self._asdict().keys()

    def values(self):
        return self._asdict().values()

    def items(self):
        return self._asdict().items()

    def _asdict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "user_id": self.user_id,
            "status": self.status,
            "payload": self.payload,
            "reward_units": self.reward_units,
            "decision_reason": self.decision_reason,
            "admin_user_id": self.admin_user_id,
            "published_task_id": self.published_task_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


# Backward-compat aliases used by task_request_admin.
TaskRequest = _RequestRow
TaskRequestError = _TaskRequestStoreError


def utc_now_iso() -> str:
    """Public hook used by task_request_store + owner lifecycle helpers."""
    return datetime.now(timezone.utc).isoformat()


def _decode_payload(record: dict[str, Any]) -> dict[str, Any]:
    raw = record.get("payload_json") or record.get("payload")
    if raw is None:
        return {}
    return _coerce_payload(raw)


def _decode_history(record: dict[str, Any]) -> list[dict[str, Any]]:
    raw = record.get("history_json")
    if raw is None or raw == "":
        return []
    try:
        decoded = _json.loads(raw)
    except Exception:  # noqa: S110
        return []
    if isinstance(decoded, list):
        return decoded
    return []


def _decode_row(record: dict[str, Any]) -> _RequestRow:
    return _RequestRow(
        request_id=int(record["request_id"]),
        user_id=int(record["user_id"]),
        status=record["status"],
        payload=_decode_payload(record),
        reward_units=int(record.get("reward_units", 0) or 0),
        decision_reason=record.get("decision_reason"),
        admin_user_id=record.get("decided_by"),
        published_task_id=record.get("published_task_id"),
        created_at=record.get("created_at"),
        updated_at=record.get("updated_at"),
        history=_decode_history(record),
    )


def _coerce_payload(raw: Any) -> dict[str, Any]:
    if isinstance(raw, dict):
        return raw
    try:
        decoded = _json.loads(raw)
    except Exception:  # noqa: S110
        return {}
    if isinstance(decoded, dict):
        return decoded
    return {}


# ── existing read helpers (unchanged behavior) ────────────────────────────

def get_request(request_id: int) -> _RequestRow | None:
    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
    if row is None:
        return None
    return _decode_row(dict(row))


def list_for_user(user_id: int) -> list[_RequestRow]:
    with db.get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM user_task_requests WHERE user_id = ? ORDER BY created_at DESC",
            (user_id,),
        ).fetchall()
    return [_decode_row(dict(row)) for row in rows]


def create_request(user_id: int, payload: dict[str, Any]) -> _RequestRow:
    from task_request_store import _TaskRequestStoreError

    title = (payload.get("title") or "").strip()
    description = (payload.get("description") or "").strip()
    provider = (payload.get("provider") or "").strip().lower()
    action = (payload.get("action") or "").strip().lower()
    target_ref = (payload.get("target_ref") or "").strip()
    reward_text = (payload.get("reward") or "").strip()

    if not title:
        raise _TaskRequestStoreError("title is required")
    if not description:
        raise _TaskRequestStoreError("description is required")
    if "\n" in title or "\r" in title:
        raise _TaskRequestStoreError("title must be a single line")
    if len(description) > 1000:
        raise _TaskRequestStoreError("description is too long")
    if provider not in ("instagram", "tiktok", "youtube", "x", "telegram"):
        raise _TaskRequestStoreError("unknown provider")
    allowed_actions = {
        "instagram": {"follow", "like", "comment", "story_view"},
        "tiktok": {"follow", "like", "video_view"},
        "youtube": {"subscribe", "like", "comment"},
        "x": {"follow", "like", "retweet"},
        "telegram": {"join_channel", "join_chat"},
    }
    if action not in allowed_actions.get(provider, set()):
        raise _TaskRequestStoreError("action not allowed for this provider")
    if target_ref and not target_ref.startswith(("http://", "https://")):
        raise _TaskRequestStoreError("target_ref must be a URL")
    try:
        reward = float(reward_text)
    except Exception:  # noqa: S110
        raise _TaskRequestStoreError("reward must be a number")
    if reward <= 0:
        raise _TaskRequestStoreError("reward must be positive")
    if reward > 10_000:
        raise _TaskRequestStoreError("reward is too high")
    if round(reward, 8) != reward:
        raise _TaskRequestStoreError("reward has too many decimals")

    reward_units = int(round(reward * 100_000_000))

    now = utc_now_iso()
    with db.get_connection() as conn:
        cur = conn.execute(
            """
            INSERT INTO user_task_requests
                (user_id, status, payload_json, reward_units, decision_reason,
                 decided_by, published_task_id, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                "pending",
                _json.dumps(payload),
                reward_units,
                None,
                None,
                None,
                now,
                now,
            ),
        )
        conn.commit()
        request_id = int(cur.lastrowid)
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
        record = dict(row) if row else {
            "request_id": request_id,
            "user_id": user_id,
            "status": "pending",
            "payload_json": _json.dumps(payload),
            "reward_units": reward_units,
            "decision_reason": None,
            "decided_by": None,
            "published_task_id": None,
            "created_at": now,
            "updated_at": now,
            "history_json": "[]",
        }
    return _decode_row(record)


def resubmit_request(
    request_id: int, user_id: int, body: dict[str, Any]
) -> _RequestRow:
    from task_request_store import _TaskRequestStoreError

    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
    if row is None:
        raise _TaskRequestStoreError("request not found")
    record = dict(row)
    if int(record["user_id"]) != user_id:
        raise _TaskRequestStoreError("request not found")
    if record["status"] != "changes_requested":
        raise _TaskRequestStoreError(
            "can only resubmit a request returned for changes"
        )

    title = (body.get("title") or "").strip()
    description = (body.get("description") or "").strip()
    if not title:
        raise _TaskRequestStoreError("title is required")
    if "\n" in title or "\r" in title:
        raise _TaskRequestStoreError("title must be a single line")
    if not description:
        raise _TaskRequestStoreError("description is required")
    if len(description) > 1000:
        raise _TaskRequestStoreError("description is too long")
    reward_text = (body.get("reward") or "").strip()
    try:
        reward = float(reward_text)
    except Exception:  # noqa: S110
        raise _TaskRequestStoreError("reward must be a number")
    if reward <= 0:
        raise _TaskRequestStoreError("reward must be positive")
    if reward > 10_000:
        raise _TaskRequestStoreError("reward is too high")
    if round(reward, 8) != reward:
        raise _TaskRequestStoreError("reward has too many decimals")
    reward_units = int(round(reward * 100_000_000))

    existing = _decode_payload(record)
    updated_payload = {**existing, "title": title, "description": description}
    now = utc_now_iso()
    with db.get_connection() as conn:
        cur = conn.execute(
            """
            UPDATE user_task_requests
            SET status = ?, payload_json = ?, reward_units = ?, updated_at = ?
            WHERE request_id = ?
            """,
            (
                "pending",
                _json.dumps(updated_payload),
                reward_units,
                now,
                request_id,
            ),
        )
        conn.commit()
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
        record = dict(row) if row else {
            "request_id": request_id,
            "user_id": user_id,
            "status": "pending",
            "payload_json": _json.dumps(updated_payload),
            "reward_units": reward_units,
            "decision_reason": None,
            "decided_by": None,
            "published_task_id": None,
            "created_at": None,
            "updated_at": now,
            "history_json": "[]",
        }
    return _decode_row(record)


def admin_return_request(
    request_id: int, admin_user_id: int, reason: str
) -> _RequestRow | None:
    from task_request_store import _TaskRequestStoreError

    if not isinstance(reason, str) or not reason.strip():
        raise _TaskRequestStoreError("reason is required")
    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
    if row is None:
        return None
    record = dict(row)
    if record["status"] != "pending":
        raise _TaskRequestStoreError(
            "only pending requests can be returned for changes"
        )
    now = utc_now_iso()
    with db.get_connection() as conn:
        cur = conn.execute(
            """
            UPDATE user_task_requests
            SET status = ?, decision_reason = ?, decided_by = ?, updated_at = ?
            WHERE request_id = ?
            """,
            (
                "changes_requested",
                reason.strip(),
                admin_user_id,
                now,
                request_id,
            ),
        )
        conn.commit()
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
        record = dict(row) if row else {
            "request_id": request_id,
            "user_id": int(record["user_id"]),
            "status": "changes_requested",
            "payload_json": record.get("payload_json"),
            "reward_units": int(record.get("reward_units", 0) or 0),
            "decision_reason": reason.strip(),
            "decided_by": admin_user_id,
            "published_task_id": record.get("published_task_id"),
            "created_at": record.get("created_at"),
            "updated_at": now,
            "history_json": "[]",
        }
    return _decode_row(record)


# ── Phase 17/18 owner lifecycle write-helpers ──────────────────────────────

def get_request_by_published_task(
    published_task_id: int,
) -> _RequestRow | None:
    """Return the request that published the given public task id, or None."""
    if not isinstance(published_task_id, int) or published_task_id <= 0:
        return None
    with db.get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE published_task_id = ?",
            (published_task_id,),
        ).fetchone()
    if row is None:
        return None
    return _decode_row(dict(row))


def owner_edit_payload(
    conn: Any,
    request_id: int,
    user_id: int,
    payload: dict[str, Any],
) -> _RequestRow | None:
    """Rewrite title/description only for the given request, preserving other
    payload fields.  Returns the refreshed row, or None on any lookup failure.
    """
    if not isinstance(payload, dict):
        return None
    allowed = {"title", "description"}
    payload = {k: v for k, v in payload.items() if k in allowed}
    title = (payload.get("title") or "").strip()
    description = (payload.get("description") or "").strip()
    if not title or not description:
        return None
    if "\n" in title or "\r" in title:
        return None
    if len(description) > 1000:
        return None

    with conn:
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
    if row is None:
        return None
    record = dict(row)
    if int(record["user_id"]) != user_id:
        return None
    existing = _decode_payload(record)
    updated_payload = {**existing, "title": title, "description": description}
    now = utc_now_iso()
    with conn:
        conn.execute(
            """
            UPDATE user_task_requests
            SET payload_json = ?, updated_at = ?
            WHERE request_id = ?
            """,
            (
                _json.dumps(updated_payload),
                now,
                request_id,
            ),
        )
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
        record = dict(row) if row else {
            "request_id": request_id,
            "user_id": user_id,
            "status": record.get("status"),
            "payload_json": _json.dumps(updated_payload),
            "reward_units": int(record.get("reward_units", 0) or 0),
            "decision_reason": record.get("decision_reason"),
            "decided_by": record.get("decided_by"),
            "published_task_id": record.get("published_task_id"),
            "created_at": record.get("created_at"),
            "updated_at": now,
            "history_json": record.get("history_json") or "[]",
        }
    return _decode_row(record)


def owner_append_history_event(
    conn: Any,
    request_id: int,
    user_id: int,
    event: str,
) -> _RequestRow | None:
    """Append a guarded lifecycle event and return the refreshed row.

    Only the three owner-lifecycle event names are accepted; everything else is
    rejected so the append-only log stays auditable.
    """
    allowed_events = {"owner_pause", "owner_resume", "owner_archive"}
    if event not in allowed_events:
        return None
    with conn:
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
    if row is None:
        return None
    record = dict(row)
    if int(record["user_id"]) != user_id:
        return None
    ts = utc_now_iso()
    event_payload = _json.dumps({"event": event, "at": ts})
    existing_history = _decode_history(record)
    updated_history = existing_history + [event_payload]
    with conn:
        conn.execute(
            "UPDATE user_task_requests SET history_json = ? WHERE request_id = ?",
            (_json.dumps(updated_history), request_id),
        )
        conn.execute(
            "INSERT INTO user_task_request_history (request_id, event_payload, created_at) VALUES (?, ?, ?)",
            (request_id, event_payload, ts),
        )
        row = conn.execute(
            "SELECT * FROM user_task_requests WHERE request_id = ?",
            (request_id,),
        ).fetchone()
        record = dict(row) if row else {
            "request_id": request_id,
            "user_id": user_id,
            "status": record.get("status"),
            "payload_json": record.get("payload_json"),
            "reward_units": int(record.get("reward_units", 0) or 0),
            "decision_reason": record.get("decision_reason"),
            "decided_by": record.get("decided_by"),
            "published_task_id": record.get("published_task_id"),
            "created_at": record.get("created_at"),
            "updated_at": ts,
            "history_json": _json.dumps(updated_history),
        }
    return _decode_row(record)


def _load_history(conn: Any, request_id: int) -> list[dict[str, Any]]:
    if conn is None:
        return []
    rows = conn.execute(
        "SELECT event_payload FROM user_task_request_history WHERE request_id = ? ORDER BY created_at ASC",
        (request_id,),
    ).fetchall()
    out: list[dict[str, Any]] = []
    for r in rows:
        try:
            decoded = _json.loads(r["event_payload"])
        except Exception:  # noqa: S110
            continue
        if isinstance(decoded, dict):
            out.append(decoded)
    return out


# ── error types ─────────────────────────────────────────────────────────────

class _TaskRequestStoreError(Exception):
    """Lightweight store validation error used internally by task_routes and
    task_request_store.  Never surfaced directly to clients.
    """


TaskRequestError = _TaskRequestStoreError  # exported for downstream modules


def validate_payload(body: dict[str, Any]) -> dict[str, Any]:
    """Client-visible validation mirror used by task_routes.create_task_request.

    Returns the accepted subset of fields so callers can forward it directly.
    """
    from task_request_store import _TaskRequestStoreError

    try:
        return _validate_create_fields(body)
    except _TaskRequestStoreError as exc:
        raise ValueError(str(exc)) from exc


def _validate_create_fields(body: dict[str, Any]) -> dict[str, Any]:
    title = (body.get("title") or "").strip()
    description = (body.get("description") or "").strip()
    provider = (body.get("provider") or "").strip().lower()
    action = (body.get("action") or "").strip().lower()
    target_ref = (body.get("target_ref") or "").strip()
    reward_text = (body.get("reward") or "").strip()

    if not title:
        raise _TaskRequestStoreError("title is required")
    if not description:
        raise _TaskRequestStoreError("description is required")
    if "\n" in title or "\r" in title:
        raise _TaskRequestStoreError("title must be a single line")
    if len(description) > 1000:
        raise _TaskRequestStoreError("description is too long")
    if provider not in ("instagram", "tiktok", "youtube", "x", "telegram"):
        raise _TaskRequestStoreError("unknown provider")
    allowed_actions = {
        "instagram": {"follow", "like", "comment", "story_view"},
        "tiktok": {"follow", "like", "video_view"},
        "youtube": {"subscribe", "like", "comment"},
        "x": {"follow", "like", "retweet"},
        "telegram": {"join_channel", "join_chat"},
    }
    if action not in allowed_actions.get(provider, set()):
        raise _TaskRequestStoreError("action not allowed for this provider")
    if target_ref and not target_ref.startswith(("http://", "https://")):
        raise _TaskRequestStoreError("target_ref must be a URL")
    try:
        reward = float(reward_text)
    except Exception:  # noqa: S110
        raise _TaskRequestStoreError("reward must be a number")
    if reward <= 0:
        raise _TaskRequestStoreError("reward must be positive")
    if reward > 10_000:
        raise _TaskRequestStoreError("reward is too high")
    if round(reward, 8) != reward:
        raise _TaskRequestStoreError("reward has too many decimals")

    return {
        "title": title,
        "description": description,
        "provider": provider,
        "action": action,
        "target_ref": target_ref or None,
        "reward": reward_text,
    }
