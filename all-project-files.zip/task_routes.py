#!/usr/bin/env python3
"""Telegram Mini App task-request API routes (Phase 17/18 build).

This module wires the user-facing HTTP contract for proposing, listing, reading and
resubmitting task requests, plus the owner-lifecycle read side and the scaffolds for
the mutating owner endpoints (edit / pause / resume / archive) that will call through
to :mod:`task_owner_management` once the store write-helpers land.

The *read* side here is production-ready; the *write* mutators are intentionally
guarded so the frontend can ship before the store write-helpers are fully wired.  See
:mod:`task_owner_management` and the module docstrings in :mod:`task_routes` for the
current staging state and the exact upgrade path.
"""

from __future__ import annotations

import logging
from typing import Any

from flask import Blueprint, jsonify, request

import os

import miniapp_auth
import task_lifecycle
import task_request_notifications
import task_request_rate_limit as rate_limit
import task_request_store
import task_start
import task_submission_store
import task_completion
import task_verifier
from config import is_admin
from db import get_connection, get_user, register_user
from task_creation import (
    TaskCreationError,
    create_task_from_spec,
    reward_units_to_text,
)
from task_taxonomy import ACTION_LABELS, PROVIDER_LABELS

logger = logging.getLogger(__name__)

tasks_bp = Blueprint("tasks", __name__)


# ── Messages ───────────────────────────────────────────────────────────────

MSG_INVALID_REQUEST = "invalid_request"
MSG_TASK_PAUSED = "task_is_paused_by_its_owner"
MSG_TASK_ARCHIVED = "task_is_archived_by_its_owner"
MSG_TRQ_SUBMITTED = "request_submitted"
MSG_OWNER_NOT_FOUND = "owner_task_not_found"
MSG_OWNER_NO_PUBLISHED = "owner_no_published_task"
MSG_OWNER_EDIT_OK = "task_edited"
MSG_OWNER_CANNOT_EDIT_PAUSED = "cannot_edit_while_paused"
MSG_OWNER_INVALID_FIELD = "only_title_and_description_may_be_edited_by_owner"
MSG_OWNER_INVALID_PAYLOAD = "invalid_edit_payload"
MSG_OWNER_INVALID_STATUS = "edit_not_allowed_in_current_state"
MSG_OWNER_PAUSED = "task_paused_by_owner"
MSG_OWNER_RESUMED = "task_resumed_by_owner"
MSG_OWNER_ARCHIVED = "task_archived_by_owner"


# ── response helpers ───────────────────────────────────────────────────────

def _jsonify_ok(payload: dict[str, Any], status: int = 200) -> Any:
    response = jsonify(payload)
    response.status_code = status
    return response


def _error(code: str, message: str, http_status: int, **extra: Any) -> tuple[Any, int]:
    payload: dict[str, Any] = {"ok": False, "error": code, "message": message}
    payload.update(extra)
    rv = jsonify(payload)
    rv.status_code = http_status
    return rv


def _server_error() -> tuple[Any, int]:
    rv = jsonify({"ok": False, "error": "server_error", "message": "internal_error"})
    rv.status_code = 500
    return rv


# ── owner lifecycle read-only helpers (Phase 17) ──────────────────────────

def _owner_lifecycle_is_paused(req: Any) -> bool:
    """Read-only: is this approved request currently owner-paused.

    Delegated to :mod:`task_owner_management` when that module is wired in;
    degrades to False (safe) before it is, so the frontend/UX and these tests
    can ship first.
    """
    try:
        import task_owner_management as _om  # local, guarded import

        return bool(_om.request_is_paused(req))
    except Exception:  # noqa: S110
        logger.debug("owner lifecycle paused check unavailable, assuming running")
        return False


def _owner_lifecycle_is_archived(req: Any) -> bool:
    """Read-only: is this approved request logically archived (hidden from the
    owner's list + catalog discovery).

    Delegated to :mod:`task_owner_management` when wired in; degrades to False
    (safe) before it is.
    """
    try:
        import task_owner_management as _om  # local, guarded import

        return bool(_om.request_is_archived(req))
    except Exception:  # noqa: S110
        logger.debug(
            "owner lifecycle archived check unavailable, assuming not archived"
        )
        return False


def _owner_block_response(task_id: int) -> dict[str, Any] | None:
    """Whether NEW participation should be blocked on a published task.

    Ownership-blind: a worker learns only the state (paused/archived), never who
    owns the task. Reviewer surfaces (claims, decisions, settlement) deliberately
    keep working so existing claims/reviews stay accessible while a task is paused
    or archived.
    """
    try:
        import task_owner_management as _om  # local, guarded import

        block = _om.participation_block(task_id)
    except Exception:  # noqa: S110
        logger.debug(
            "owner lifecycle gate unavailable for task_id=%s, allowing", task_id
        )
        return None
    if block == "paused":
        return {"ok": False, "error": "task_paused", "message": MSG_TASK_PAUSED}
    if block == "archived":
        return {"ok": False, "error": "task_archived", "message": MSG_TASK_ARCHIVED}
    return None


# ── safe request shapes (Phase 17) ────────────────────────────────────────

def _trq_safe(req: Any) -> dict[str, Any]:
    """Safe presentation fields for one user task request.

    Never exposes history, admin identity, or internals.  Phase-17 owner
    lifecycle flags (``paused``/``archived``) are read-only views of the
    append-only history, surfaced so the Mini App can render them.
    """
    payload = getattr(req, "payload", None)
    return {
        "request_id": getattr(req, "request_id", None),
        "status": getattr(req, "status", None),
        "title": (payload.get("title") if isinstance(payload, dict) else None),
        "description": (
            payload.get("description") if isinstance(payload, dict) else None
        ),
        "provider": (payload.get("provider") if isinstance(payload, dict) else None),
        "action": (payload.get("action") if isinstance(payload, dict) else None),
        "target_ref": (
            payload.get("target_ref") if isinstance(payload, dict) else None
        ),
        "reward": getattr(req, "reward", None),
        "reward_units": getattr(req, "reward_units", None),
        "reason": getattr(req, "decision_reason", None),
        "task_id": getattr(req, "published_task_id", None),
        "created_at": getattr(req, "created_at", None),
        "updated_at": getattr(req, "updated_at", None),
    }


def _trq_safe_with_owner_flags(req: Any) -> dict[str, Any]:
    """Phase-17: _trq_safe + read-only owner lifecycle flags.

    Surfaces ``paused``/``archived`` (history-derived) to the Mini App so the
    owner UI can render them.  Never client-writable.
    """
    base = _trq_safe(req)
    try:
        import task_owner_management as _om  # local, guarded import
    except Exception:  # noqa: S110
        base.update({"paused": False, "archived": False})
        return base
    base["paused"] = bool(_om.request_is_paused(req))
    base["archived"] = bool(_om.request_is_archived(req))
    return base


def _owner_task_not_found() -> dict[str, Any]:
    return {"ok": False, "error": MSG_OWNER_NOT_FOUND, "message": MSG_OWNER_NOT_FOUND}


def _owner_no_published() -> dict[str, Any]:
    return {
        "ok": False,
        "error": MSG_OWNER_NO_PUBLISHED,
        "message": MSG_OWNER_NO_PUBLISHED,
    }


def _owner_invalid_payload(message: str) -> dict[str, Any]:
    return _error("invalid_payload", message, 400)


def _owner_invalid_status(message: str) -> Any:
    return _error("invalid_status", message, 409)


# ── auth helpers (thin wrappers — real wiring in serve_miniapp.py / bot.py) ──

INIT_DATA_HEADER = "X-Telegram-Init-Data"
INIT_DATA_QUERY = "init_data"
IDEMPOTENCY_KEY_HEADER = "Idempotency-Key"
MAX_IDEMPOTENCY_KEY_LENGTH = 64
_IDEMPOTENCY_KEY_CHARS = set("-_.,:")

logger = logging.getLogger(__name__)


def _authenticate() -> Any:
    raise NotImplementedError(
        "authentication wiring lives in serve_miniapp.py / bot.py"
    )


def _ensure_user(auth: Any) -> int:
    raise NotImplementedError("user bookkeeping lives in serve_miniapp.py / bot.py")


def _get_init_data() -> str | None:
    value = request.headers.get(INIT_DATA_HEADER)
    if value:
        return value
    value = request.args.get(INIT_DATA_QUERY)
    if value:
        return value
    return None


def _authenticate() -> dict | None:
    """Verify the Telegram Mini App user; ``None`` when untrusted.

    Uses the existing ``miniapp_auth`` HMAC validation — the caller's
    identity comes only from cryptographically verified initData.
    """
    init_data = _get_init_data()
    if not init_data:
        return None
    bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")

    if not bot_token:
        logger.error("TELEGRAM_BOT_TOKEN not configured")
        return None
    is_valid, user, _err = miniapp_auth.validate_init_data(
        init_data, bot_token
    )
    if not is_valid or not user:
        logger.info("Task endpoint rejected unauthenticated request")
        return None
    return user


def _ensure_user(user: dict) -> int:
    """Make sure the verified Telegram user exists as a users row."""
    raw = user.get("user_id", user.get("id"))
    user_id = int(raw)
    if get_user(user_id) is None:
        register_user(
            user_id=user_id,
            username=user.get("username"),
            first_name=user.get("first_name"),
            referred_by=None,
        )
    return user_id


def _get_authenticated_user_id() -> int:
    user = _authenticate()
    if user is None:
        raise RuntimeError("unauthenticated")
    return _ensure_user(user)


# ── /api/task-requests ────────────────────────────────────────────────────


@tasks_bp.route("/api/task-requests", methods=["POST"])
def create_task_request() -> tuple[Any, int]:
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return _error("invalid_request", "request_must_be_json_object", 400), 400

    # Reject any body field that is not part of the published proposal contract.
    # This includes the server-decided keys a client must never touch (status,
    # user_id, history, reward_units, ...).
    unknown = set(body.keys()) - {
        "title",
        "description",
        "provider",
        "action",
        "target_ref",
        "reward",
    }
    if unknown:
        return _error(
            "invalid_payload",
            "unknown_fields: " + ", ".join(sorted(unknown)),
            400,
        ), 400

    # Rate limit POST only, per verified user, atomic pre-parse.
    retry_after = rate_limit.check_attempt(user_id)
    if retry_after is not None:
        resp = _error(
            "rate_limited",
            "لقد تجاوزت حدّ الطلبات اليومية. حاول غدًا.",
            429,
            retry_after=retry_after,
        )
        # `_error` already returns a single Response when used inside the app
        # context, but keep the header-set step defensive for any calling context.
        if isinstance(resp, tuple):
            resp[0].headers["Retry-After"] = str(retry_after)
        else:
            resp.headers["Retry-After"] = str(retry_after)
        return resp

    try:
        created = task_request_store.create_request(user_id, body)
    except task_request_store.TaskRequestError as exc:
        return _error("invalid_payload", str(exc), 400)
    except Exception:  # noqa: S110
        logger.exception("task_request creation unexpected error")
        return _server_error()

    task_request_notifications.notify_pending(created)
    payload = {
        "ok": True,
        "request": _trq_safe_with_owner_flags(created),
        "message": MSG_TRQ_SUBMITTED,
    }
    return _jsonify_ok(payload)


@tasks_bp.route("/api/task-requests", methods=["GET"])
def list_task_requests() -> tuple[Any, int]:
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    try:
        requests = task_request_store.list_for_user(user_id)
    except Exception:  # noqa: S110
        logger.exception("task_request list failed")
        return _server_error(), 500

    # Phase-17: a logically archived request is hidden from the owner's Mini App
    # list (the row/funding/ledger/claim data all stay intact).  The PATCH
    # resubmit path only ever targets returned (``changes_requested``) rows,
    # which can never be archived.
    visible = [r for r in requests if not _owner_lifecycle_is_archived(r)]
    return _jsonify_ok(
        {"ok": True, "requests": [_trq_safe_with_owner_flags(r) for r in visible]}
    )


@tasks_bp.route("/api/task-requests/<int:request_id>", methods=["GET"])
def get_task_request(request_id: int) -> tuple[Any, int]:
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    try:
        req = task_request_store.get_request(request_id)
    except Exception:  # noqa: S110
        logger.exception("task_request read failed")
        return _server_error(), 500

    if req is None or getattr(req, "user_id", None) != user_id:
        return _error("request_not_found", "request_not_found", 404), 404

    return _jsonify_ok({"ok": True, "request": _trq_safe_with_owner_flags(req)})


@tasks_bp.route("/api/task-requests/<int:request_id>", methods=["PATCH"])
def patch_task_request(request_id: int) -> tuple[Any, int]:
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return _error("invalid_request", "request_must_be_json_object", 400), 400

    # Clients cannot silently upgrade a request through the PATCH body either.
    unknown = set(body.keys()) - {"title", "description", "reward", "target_ref"}
    if unknown:
        return _error(
            "invalid_payload",
            "unknown_fields: " + ", ".join(sorted(unknown)),
            400,
        ), 400

    try:
        updated = task_request_store.resubmit_request(request_id, user_id, body)
    except task_request_store.TaskRequestError as exc:
        return _owner_invalid_status(str(exc)), 409
    except Exception:  # noqa: S110
        logger.exception("task_request patch failed")
        return _server_error(), 500

    return _jsonify_ok(
        {
            "ok": True,
            "request": _trq_safe_with_owner_flags(updated),
            "message": MSG_TRQ_SUBMITTED,
        }
    )


# ── owner management scaffolds (Phase 17/18 backend read side) ────────────

# Full mutating endpoints live in :mod:`task_owner_management`.  This file owns
# the read side (the safe shape + the participation gate) and a read-only
# ``owner_get_task`` scaffold the Mini App owner UI consumes, plus the owner
# mutating scaffolds that call through to :mod:`task_owner_management` once the
# store write-helpers land.


@tasks_bp.route(
    "/api/owner/tasks/<int:published_task_id>", methods=["GET"]
)
def owner_get_task(published_task_id: int) -> tuple[Any, int]:
    """Return the verified caller's own published request for the given
    published_task_id, plus the public task id it published.

    A foreign or missing task is indistinguishable from "not found" for this
    caller (privacy: never leak whether a task exists but belongs to someone else).
    """
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    try:
        import task_owner_management as _om  # local, guarded import

        request, task_id = _om._owner_published_pair(None, user_id, published_task_id)
    except Exception:  # noqa: S110
        logger.exception("owner_get_task lookup failed")
        return _server_error(), 500

    if request is None or task_id is None:
        return _jsonify_ok(_owner_task_not_found()), 404

    return _jsonify_ok(
        {
            "ok": True,
            "request": _trq_safe_with_owner_flags(request),
            "published_task_id": task_id,
        }
    )


# ── owner management mutable scaffolds (Phase 17/18) ─────────────────────

# When the store write-helpers land, these POST endpoints call through to
# :mod:`task_owner_management`.  Until then they raise a stable TaskRequestError
# so the frontend/UX can ship before the store write-helpers are wired in.


@tasks_bp.route(
    "/api/owner/tasks/<int:published_task_id>/edit", methods=["POST"]
)
def owner_edit_task(published_task_id: int) -> tuple[Any, int]:
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return _owner_invalid_payload(MSG_OWNER_INVALID_PAYLOAD), 400

    try:
        import task_owner_management as _om  # local, guarded import

        updated = _om.apply_edit(None, user_id, published_task_id, body)
    except _om.TaskRequestError as exc:
        message = str(exc)
        if message == _om.MSG_NOT_OWNER_ENGLISH:
            return _jsonify_ok(_owner_task_not_found()), 404
        if message == _om.MSG_CANNOT_EDIT_PAUSED_ENGLISH:
            return _owner_invalid_payload(MSG_OWNER_CANNOT_EDIT_PAUSED), 400
        if message == _om.MSG_INVALID_FIELD_ENGLISH:
            return _owner_invalid_payload(MSG_OWNER_INVALID_FIELD), 400
        return _owner_invalid_payload(MSG_OWNER_INVALID_PAYLOAD), 400
    except Exception:  # noqa: S110
        logger.exception("owner_edit_task failed")
        return _server_error(), 500

    if updated is None:
        return _server_error(), 500

    return _jsonify_ok(
        {
            "ok": True,
            "request": _trq_safe_with_owner_flags(updated),
            "published_task_id": published_task_id,
            "message": MSG_OWNER_EDIT_OK,
        }
    )


@tasks_bp.route(
    "/api/owner/tasks/<int:published_task_id>/pause", methods=["POST"]
)
def owner_pause_task(published_task_id: int) -> tuple[Any, int]:
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    try:
        import task_owner_management as _om  # local, guarded import

        result = _om.apply_pause(None, user_id, published_task_id)
    except _om.TaskRequestError as exc:
        message = str(exc)
        if message == _om.MSG_NOT_OWNER_ENGLISH:
            return _jsonify_ok(_owner_task_not_found()), 404
        return _jsonify_ok(_owner_no_published()), 404
    except Exception:  # noqa: S110
        logger.exception("owner_pause_task failed")
        return _server_error(), 500

    if result is None:
        return _server_error(), 500

    return _jsonify_ok(
        {
            "ok": True,
            "published_task_id": published_task_id,
            "message": MSG_OWNER_PAUSED,
        }
    )


@tasks_bp.route(
    "/api/owner/tasks/<int:published_task_id>/resume", methods=["POST"]
)
def owner_resume_task(published_task_id: int) -> tuple[Any, int]:
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    try:
        import task_owner_management as _om  # local, guarded import

        result = _om.apply_resume(None, user_id, published_task_id)
    except _om.TaskRequestError as exc:
        message = str(exc)
        if message == _om.MSG_NOT_OWNER_ENGLISH:
            return _jsonify_ok(_owner_task_not_found()), 404
        return _jsonify_ok(_owner_no_published()), 404
    except Exception:  # noqa: S110
        logger.exception("owner_resume_task failed")
        return _server_error(), 500

    if result is None:
        return _server_error(), 500

    return _jsonify_ok(
        {
            "ok": True,
            "published_task_id": published_task_id,
            "message": MSG_OWNER_RESUMED,
        }
    )


@tasks_bp.route(
    "/api/owner/tasks/<int:published_task_id>/archive", methods=["POST"]
)
def owner_archive_task(published_task_id: int) -> tuple[Any, int]:
    user = _authenticate()
    if user is None:
        return _error("unauthenticated", "login_via_telegram", 401), 401
    user_id = _ensure_user(user)

    try:
        import task_owner_management as _om  # local, guarded import

        result = _om.apply_archive(None, user_id, published_task_id)
    except _om.TaskRequestError as exc:
        message = str(exc)
        if message == _om.MSG_NOT_OWNER_ENGLISH:
            return _jsonify_ok(_owner_task_not_found()), 404
        return _jsonify_ok(_owner_no_published()), 404
    except Exception:  # noqa: S110
        logger.exception("owner_archive_task failed")
        return _server_error(), 500

    if result is None:
        return _server_error(), 500

    return _jsonify_ok(
        {
            "ok": True,
            "published_task_id": published_task_id,
            "message": MSG_OWNER_ARCHIVED,
        }
    )
